package Live_Test;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;

public class LiveReport_ReadingAggregates {
public static void main(String[] args) throws IOException {
	String Filepath=args[0];
	String TimeInterval=args[1];
	String TestStartTime=args[2];
	List<String> results = new ArrayList<String>();
	List<String> Filepathresults = new ArrayList<String>();
	List<String> TransactionsToBeChecked = new ArrayList<String>();
	List<String> FileContent = new ArrayList<String>();
	List<String> TransactionsVerifiedData = new ArrayList<String>();
	ArrayList<String> ErrorvalueData = new ArrayList<String>();
	ArrayList<String> BreachesvalueData = new ArrayList<String>();
String NewFilepath=Filepath+"\\ReportAutomation\\Reports\\PerformanceReport-20161103\\";
String Filepath_TransactionsToBeChecked=Filepath+"\\Transactions_ToBe_Checked.csv";

BufferedWriter output = null;
BufferedWriter output1 = null;
File file2 = new File(Filepath+"\\final\\PerformanceSummaryReport"+ ".html");
String FilenamewithDate="";

output = new BufferedWriter(new FileWriter(file2));

output.write("<html>"
		+"<head>"
		+"<style>"
		+"table, td, th {"    
		+"    border: 1px solid #ddd;"
		+"    text-align: left;"
		+"}"
		+"table {"
		+"    border-collapse: collapse;"
		+"    width: 100%;"
		+"}"
		+"th, td {"
		+"    padding: 15px;"
		+"}"
		+"</style>"
		+"</head>"
		+"<body>"
		+"<center><h2><font face=\"Calibri\" color=\"black\"><u>PERFORMANCE TEST LIVE REPORT AFTER :"+TimeInterval+"</u></font></h2></center>"
		+"<h3><font face=\"Calibri\" color=\"black\"><b>Test Start Time: "+TestStartTime+" BST</b></font></h3>"
		+"<h3><font face=\"Calibri\" color=\"black\"><u>KEY OBSERVATIONS:</u></font></h3>"
		+"<center><table style=\"width: 600px\">"
		+"  <tr style=\"background-color: #fdfdfd\">"
		+"    <th style=\"background-color: #70cbf4\"><center><font face=\"Times New Roman\" color=\"black\">SAMPLE NAME</font></center></th>"
		+"    <th style=\"background-color: #70cbf4\"><center><font face=\"Times New Roman\" color=\"black\">SAMPLE COUNT</font></center></th>"
		+"    <th style=\"background-color: #70cbf4\"><center><font face=\"Times New Roman\" color=\"black\">90% LINE</font></center></th>"
		
		+"    <th style=\"background-color: #70cbf4\"><center><font face=\"Times New Roman\" color=\"black\">ERROR%</font></center></th>"
		+"  </tr>");
File file1 = new File(Filepath_TransactionsToBeChecked);
FileReader fr1 = new FileReader(file1);
BufferedReader br1 = new BufferedReader(fr1);


  String st1=""; 
  while ((st1 = br1.readLine()) != null){
	  TransactionsToBeChecked.add(st1);
  }
  br1.close();
  fr1.close();
//System.out.println("TransactionsToBeChecked::"+TransactionsToBeChecked.size());

	File[] files = new File(NewFilepath).listFiles();
	//If this pathname does not denote a directory, then listFiles() returns null. 

	for (File file : files) {
	    if (file.isFile()) {
	        results.add(file.getName());
	    }
	}
	for(int i=0;i<results.size();i++) {
		if(results.get(i).toLowerCase().contains("aggregatereport") && results.get(i).toLowerCase().contains(".csv")) {
			System.out.println(NewFilepath+"\\"+results.get(i));
			Filepathresults.add(NewFilepath+"\\"+results.get(i));
		}
		if(results.get(i).contains("TH_aggregatereport_") && results.get(i).toLowerCase().contains(".csv")) {
			FilenamewithDate=results.get(i).substring(19, 34);
		}
	}
	
	

	for(int j=0;j<Filepathresults.size();j++) {
	//	FileContent.add(Filepathresults.get(j));
	File file = new File(Filepathresults.get(j));
	FileReader fr = new FileReader(file);
	BufferedReader br = new BufferedReader(fr);

//	FileContent.add(Filepathresults.get(j));
	  String st=""; 
	  while ((st = br.readLine()) != null){
		  FileContent.add(st);
	  }
	  br.close();
	  fr.close();
	}
	
	String[] Headers=FileContent.get(0).split(",");
	int SamplerNameIndex=0;
	int Sampler_countIndex=0;
	int NintyPercentLineIndex=0;
	int ErrorPercentageIndex=0;
	for(int c=0;c<Headers.length;c++) {
		if(Headers[c].equals("sampler_label")) {
			SamplerNameIndex=c;
		}
		if(Headers[c].equals("aggregate_report_count")) {
			Sampler_countIndex=c;
		}
		if(Headers[c].equals("aggregate_report_90%_line")) {
			NintyPercentLineIndex=c;
		}
		if(Headers[c].equals("aggregate_report_error%")) {
			ErrorPercentageIndex=c;
		}
	}
	for(int a=0;a<FileContent.size();a++) {
		String[] FileContentHeaders=FileContent.get(a).split(",");
		for(int b=0;b<TransactionsToBeChecked.size();b++) {
			String[] TransactionsToBeCheckedHeaders=TransactionsToBeChecked.get(b).split(",");
					
			if(FileContentHeaders[SamplerNameIndex].equals(TransactionsToBeCheckedHeaders[SamplerNameIndex])) {
				String Errorpercent=FileContentHeaders[ErrorPercentageIndex];
				double ErrorValue=0;
				String ErrorStringvalue="";
			if(Errorpercent.length()>5) {
				//	Errorpercent=Errorpercent.substring(0,3);
				
				ErrorValue=Double.parseDouble(Errorpercent)*100;
				 ErrorStringvalue=String.valueOf(ErrorValue).substring(0,5);
			}
			else {
				ErrorValue=Double.parseDouble(Errorpercent)*100;
				 ErrorStringvalue=String.valueOf(ErrorValue);
			}
				TransactionsVerifiedData.add(FileContentHeaders[SamplerNameIndex]+","+FileContentHeaders[Sampler_countIndex]+","+FileContentHeaders[NintyPercentLineIndex]+","+ErrorStringvalue);
			//	System.out.println("FinalFileData::"+FileContentHeaders[SamplerNameIndex]+","+FileContentHeaders[NintyPercentLineIndex]+","+ErrorStringvalue);
			}
		}
	}
	HashMap<String, Double> hm = new HashMap<String, Double>();
	HashMap<String, Integer> hm1 = new HashMap<String, Integer>();
//	 HashMap<Integer, String> hmap = new HashMap<Integer, String>();
//	Map<Double, String> healthBenDesig =new HashMap<Double, String>();
		for(int b=0;b<FileContent.size();b++) {
			String[] TransactionsToBeCheckedHeaders=FileContent.get(b).split(",");
			String ErrorStringvalue="";
			double ErrorValue=0;
			if( !TransactionsToBeCheckedHeaders[ErrorPercentageIndex].equals("aggregate_report_error%")&&!TransactionsToBeCheckedHeaders[SamplerNameIndex].equals("TOTAL")) {
			if(TransactionsToBeCheckedHeaders[ErrorPercentageIndex].length()>6 ) {
				//	Errorpercent=Errorpercent.substring(0,3);
			//	System.out.println("String lenght::"+TransactionsToBeCheckedHeaders[ErrorPercentageIndex]);
				ErrorValue=Double.parseDouble(TransactionsToBeCheckedHeaders[ErrorPercentageIndex])*100;
				 ErrorStringvalue=String.valueOf(ErrorValue).substring(0,5);
			}
			else {
				ErrorValue=Double.parseDouble(TransactionsToBeCheckedHeaders[ErrorPercentageIndex])*100;
				 ErrorStringvalue=String.valueOf(ErrorValue);
			}
			if(ErrorValue>50)	{			
				ErrorvalueData.add(ErrorStringvalue+","+TransactionsToBeCheckedHeaders[SamplerNameIndex]);
				hm.put(TransactionsToBeCheckedHeaders[SamplerNameIndex]+"___"+TransactionsToBeCheckedHeaders[Sampler_countIndex], ErrorValue);
				}
		
			}
			if( !TransactionsToBeCheckedHeaders[NintyPercentLineIndex].equals("aggregate_report_90%_line")&&  !TransactionsToBeCheckedHeaders[SamplerNameIndex].equals("TOTAL")) {
			int Beachvalue=Integer.parseInt(TransactionsToBeCheckedHeaders[NintyPercentLineIndex]);
				if(Beachvalue>5000)	{			
					BreachesvalueData.add(TransactionsToBeCheckedHeaders[NintyPercentLineIndex]+","+TransactionsToBeCheckedHeaders[SamplerNameIndex]);
					hm1.put(TransactionsToBeCheckedHeaders[SamplerNameIndex]+"___"+TransactionsToBeCheckedHeaders[Sampler_countIndex], Beachvalue);
					}
			
				}
}
		 Set<Entry<String, Double>> set = hm.entrySet();
	        List<Entry<String, Double>> list = new ArrayList<Entry<String, Double>>(
	                set);
	        Collections.sort(list, new Comparator<Map.Entry<String, Double>>() {
	            public int compare(Map.Entry<String, Double> o1,
	                    Map.Entry<String, Double> o2) {
	                return o2.getValue().compareTo(o1.getValue());
	            }
	        });
	        
	        
	        Set<Entry<String, Integer>> set1 = hm1.entrySet();
	        List<Entry<String, Integer>> list1 = new ArrayList<Entry<String, Integer>>(
	                set1);
	        Collections.sort(list1, new Comparator<Map.Entry<String, Integer>>() {
	            public int compare(Map.Entry<String, Integer> o1,
	                    Map.Entry<String, Integer> o2) {
	                return o2.getValue().compareTo(o1.getValue());
	            }
	        });
	        
	//			 SortArrayListAscendingDescending sortArrayList = new SortArrayListAscendingDescending(ErrorvalueData);
//		 ArrayList<String> sortedArrayListAscending = sortArrayList.sortDescending();  
		 
	//	 SortArrayListAscendingDescending sortArrayList1 = new SortArrayListAscendingDescending(BreachesvalueData);
	//	 ArrayList<String> sortedArrayListAscending1 = sortArrayList1.sortDescending();  
	
	for(int k=0;k<TransactionsVerifiedData.size();k++) {
		String[] Testing=TransactionsVerifiedData.get(k).split(",");
		output.write("  <tr style=\"background-color: #fdfdfd\">"
			  +"  <td>"+Testing[0]+"</td>"
			  +"  <td>"+Testing[1]+"</td>"
			  +"  <td>"+Testing[2]+"</td>"
			  +"  <td>"+Testing[3]+"</td>"
			+"  </tr>");
		
	}
	output.write("</table></center>");
	output.write("<br />");
	output.write("<br />");
	output.write("<h3><font face=\"Calibri\" color=\"black\"><u>ERRORS OBSERVED:</u></font></h3>");
	output.write("</table></center>");
	output.write("<center><table style=\"width: 600px\">"
			+"  <tr style=\"background-color: #fdfdfd\">"
			+"    <th style=\"background-color: #70cbf4\"><center><font face=\"Times New Roman\" color=\"black\">SAMPLE NAME</font></center></th>"
			+"    <th style=\"background-color: #70cbf4\"><center><font face=\"Times New Roman\" color=\"black\">SAMPLE COUNT</font></center></th>"
			+"    <th style=\"background-color: #70cbf4\"><center><font face=\"Times New Roman\" color=\"black\">ERROR%</font></center></th>"
			+"  </tr>");
	 for (Entry<String, Double> entry : list) {
         System.out.println(entry.getKey());
		 String []Transactiondata=entry.getKey().split("___");
		 System.out.println("SizeOf Transactiondata::"+Transactiondata.length);
         output.write("  <tr style=\"background-color: #fdfdfd\">"
   			  +"  <td>"+Transactiondata[0]+"</td>"
   			+"  <td>"+Transactiondata[1]+"</td>"
   			  +"  <td>"+entry.getValue().toString().concat("00").substring(0, 5)+"</td>"
   			+"  </tr>");
     }
/*	for(int k=0;k<sortedArrayListAscending.size();k++) {
		String[] Testing=sortedArrayListAscending.get(k).split(",");
	
	
	output.write("  <tr style=\"background-color: #fdfdfd\">"
			  +"  <td>"+Testing[1]+"</td>"
			  +"  <td>"+Testing[0]+"</td>"
			+"  </tr>");

	
	}*/	
	//output.write("</table></center>");
	output.write("</table></center>");
	output.write("<br />");
	output.write("<br />");
	output.write("<h3><font face=\"Calibri\" color=\"black\"><u>BREACHES OBSERVED:</u></font></h3>");
	output.write("<center><table style=\"width: 600px\">"
			+"  <tr style=\"background-color: #fdfdfd\">"
			+"    <th style=\"background-color: #70cbf4\"><center><font face=\"Times New Roman\" color=\"black\">SAMPLE NAME</font></center></th>"
			+"    <th style=\"background-color: #70cbf4\"><center><font face=\"Times New Roman\" color=\"black\">SAMPLE COUNT</font></center></th>"
			+"    <th style=\"background-color: #70cbf4\"><center><font face=\"Times New Roman\" color=\"black\">90% LINE</font></center></th>"
			
			+"  </tr>");
	
	/*for(int k=0;k<sortedArrayListAscending1.size();k++) {
		String[] Testing=sortedArrayListAscending1.get(k).split(",");
	output.write("  <tr style=\"background-color: #fdfdfd\">"
			  +"  <td>"+Testing[1]+"</td>"
			  +"  <td>"+Testing[0]+"</td>"
			+"  </tr>");
	}*/
	 for (Entry<String, Integer> entry : list1) {
		 String []Transactiondata=entry.getKey().split("___");
		 output.write("  <tr style=\"background-color: #fdfdfd\">"
				  +"  <td>"+Transactiondata[0]+"</td>"
				+"  <td>"+Transactiondata[1]+"</td>"
				  +"  <td>"+entry.getValue()+"</td>"
				+"  </tr>");
        // System.out.println(entry);

     }
	output.write("</table></center>");
	output.write("</body>"
			+"</html>");
	
	
	
	output.close();
}

}
