package Live_Test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.StringTokenizer;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

public class Converting_To_Aggragate_IN_Ec2_LiveTest {
	public static void main(String args[]) throws IOException, InterruptedException {
		// Scanner sc=new Scanner(System.in);
		// String Filepath=sc.next();
		String Filepath = args[0];
		File file = new File(Filepath
				+ "\\ReportAutomation\\Reports\\PerformanceReport-20161103");
		String[] myFiles;
		if (file.isDirectory()) {
			myFiles = file.list();
			for (int i = 0; i < myFiles.length; i++) {
				File myFile = new File(file, myFiles[i]);
				myFile.delete();
			}
		}

		// String[][] arrayValues = new String[39][39];

		// File file = new File("exported_file.csv");

		File folder = new File(Filepath + "\\FileNames");
		File[] listOfFiles = folder.listFiles();
		System.out.println("listOfFiles" + listOfFiles.length);
		int numberoffiles = listOfFiles.length;
		//for (int a = 0; a <= (numberoffiles - 1); a++) {
			String[][] arrayValues = new String[50][50];
			String csvFile = Filepath + "\\FileNames\\Test" + "1" + ".csv";

			BufferedReader bufRdr = new BufferedReader(new FileReader(csvFile));
			String line = "";
			int row = 0;
			int col = 0;

			// read each line of text file
			while ((line = bufRdr.readLine()) != null) {
				StringTokenizer st = new StringTokenizer(line, ",");
				while (st.hasMoreTokens()) {
					// get next token and store it in the array
					arrayValues[row][col] = st.nextToken();
					col++;
				}
				row++;
				col = 0;
			}
			// close the file
			bufRdr.close();

			/*
			 * for(int k = 0; k < row; k++){ for(int l = 0; l < 5; l++){
			 * System.out.println(arrayValues[k][l]+" "+k+l); } }
			 */

		//	for (int i = 0; i < row; i++) {
				// int j=col;
			//	String copyFrom = arrayValues[i][0];
			//	String copyFrom1 = arrayValues[i][1];
				String hostname = "10.136.75.178";
			//	String username = arrayValues[i][3];
			//	String password = arrayValues[i][4];
			//	String application = arrayValues[i][5];
				/*
				 * if(application.equals("THOther")){
				 * copyFrom=copyFrom.replace("TH_errors", "THOther_errors");
				 * copyFrom=copyFrom.replace("TH_aggregatereport",
				 * "THOther_aggregatereport");
				 * copyFrom1=copyFrom1.replace("TH_errors", "THOther_errors");
				 * copyFrom1=copyFrom1.replace("TH_aggregatereport",
				 * "THOther_aggregatereport"); }
				 */
			//	File file1 = new File(copyFrom);
			//	File file2 = new File(copyFrom1);

			//	String copyTo = Filepath
			//			+ "\\ReportAutomation\\Reports\\PerformanceReport-20161103\\"
			//			+ file1.getName();
			//	String copyTo1 = Filepath
			//			+ "\\ReportAutomation\\Reports\\PerformanceReport-20161103\\"
			//			+ file2.getName();
				
			/*	if (application.equals("THOther")) {
					copyTo = copyTo.replace("TH_errors", "THOther_errors");
					copyTo = copyTo.replace("TH_aggregatereport",
							"THOther_aggregatereport");
					copyTo1 = copyTo1.replace("TH_errors", "THOther_errors");
					copyTo1 = copyTo1.replace("TH_aggregatereport",
							"THOther_aggregatereport");
				}*/
				// System.out.println("file2.getName()"+file2.getName());
				// double filelength1= file1.length();
				// double filelength1= file1.length()/(1024*1024);
				// double filelength2= file2.length();
				// double filelength2= file2.length()/(1024*1024);
				JSch jsch = new JSch();
				// JSch jsch1 = new JSch();
				Session session = null;
				// Session session1 = null;
				System.out.println("Trying to connect....." + hostname);
				try {
				//	jsch.addIdentity("D:\\Performance\\Services.pem");
					session = jsch.getSession("ec2-user", hostname, 22);
					
					jsch.addIdentity(Filepath+"\\Services.ppk");
					java.util.Properties config = new java.util.Properties();
					config.put("StrictHostKeyChecking", "no");
					// session1 = jsch1.getSession(username, hostname, 22);
					session.setConfig("StrictHostKeyChecking", "no");
					// session1.setConfig("StrictHostKeyChecking", "no");
				//	session.setPassword(password);
					// session1.setPassword(password);
					session.connect();
					// session1.connect();

				//	Channel channel = session.openChannel("sftp");
					// Channel channel1 = session1.openChannel("sftp");
				//	channel.connect();
					// channel1.connect();
				//	ChannelSftp sftpChannel = (ChannelSftp) channel;
					// ChannelSftp sftpChannel1 = (ChannelSftp) channel1;
				//	if(i==0) {
				//	long fileSize = sftpChannel.lstat(copyFrom).getSize();
				//	System.out.println("FileSize"+fileSize);
				//	Thread.sleep(10000);
				//	long fileSize2 = sftpChannel.lstat(copyFrom).getSize();
				//	System.out.println("FileSize After 10 Sec:"+fileSize2);
				//	if(fileSize!=fileSize2) {
				//		System.out.println("Test is still running....!!!!");
				//	}
				//	else {
				//		System.out.println("No Live Test is Running..!!");
				//	}
				//	}
					
				/*	 ChannelExec channelExec = (ChannelExec) session.openChannel("exec");
			            // Set the command to execute on the channel and execute the command
					// channelExec.c
					 channelExec.setCommand("cd /opt/efs/tui/jmeter/81machine/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT/data-load-test-20191207");
			            channelExec.setCommand("sh /opt/efs/tui/jmeter/81machine/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT/data-load-test-20191207/Runner.sh");
			            channelExec.connect();
			            InputStream in = channelExec.getInputStream();
			            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
			            String line1;
			            while ((line1 = reader.readLine()) != null) {
			                System.out.println(line1);
			            }

			            // Command execution completed here.

			            // Retrieve the exit status of the executed command
			            int exitStatus = channelExec.getExitStatus();
			            if (exitStatus > 0) {
			                System.out.println("Remote script exec error! " + exitStatus);
			            }
			            
			            */
			            
			            Channel channel=session.openChannel("exec");
			         //   ((ChannelExec)channel).setCommand("cd "+"/opt/efs/tui/jmeter/81machine/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT/data-load-test-20191207");
			        //    ((ChannelExec)channel).setCommand("java -jar /opt/efs/tui/jmeter/81machine/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT/data-load-test-20191207/apache-jmeter-2.9/lib/ext/cmdrunner-2.0.jar --tool Reporter --generate-csv /opt/efs/tui/jmeter/81machine/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT/data-load-test-20191207/TH_aggregatereport_20191207-152838.csv --input-jtl /opt/efs/tui/jmeter/81machine/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT/data-load-test-20191207/TH_aggregatereport_20191207-152838.jtl --plugin-type AggregateReport");
			           // ((ChannelExec)channel).setCommand("sh "+"/opt/efs/tui/jmeter/81machine/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT/data-load-test-20191207/Runner.sh");
			            ChannelExec channelExe = (ChannelExec) channel;
			            channelExe.setCommand("sh "+"/opt/efs/tui/jmeter/Runner.sh"); 
			 //           channelExe.setCommand("java -jar /opt/efs/tui/jmeter/81machine/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT/data-load-test-20191207/apache-jmeter-2.9/lib/ext/cmdrunner-2.0.jar --tool Reporter --generate-csv /opt/efs/tui/jmeter/81machine/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT/data-load-test-20191207/TH_aggregatereport_20191207-152838.csv --input-jtl /opt/efs/tui/jmeter/81machine/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT/data-load-test-20191207/TH_aggregatereport_20191207-152838.jtl --plugin-type AggregateReport");
			        
			     //       channelExe.setCommand("/home/ec2-user/jdk1.8.0_151/bin/java -jar /opt/efs/tui/jmeter/81machine/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT/data-load-test-20191207/apache-jmeter-2.9/lib/ext/cmdrunner-2.0.jar --tool Reporter --generate-csv /opt/efs/tui/jmeter/81machine/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT/data-load-test-20191207/TH_aggregatereport_20191207-152838.csv --input-jtl /opt/efs/tui/jmeter/81machine/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT/data-load-test-20191207/TH_aggregatereport_20191207-152838.jtl --plugin-type AggregateReport");
			            channel.setInputStream(null);

			            ((ChannelExec)channel).setErrStream(System.err);

			            InputStream in=channel.getInputStream();

			            channel.connect();

			          

			              if(channel.isClosed()){
			                System.out.println("exit-status: "+channel.getExitStatus());
			            //    break;
			              }
			             
			            
			            
			            
				//	System.out.println("Copying....." + (a + 1) + "."
				//			+ file1.getName());
				//	sftpChannel.get(copyFrom, copyTo);
				//	System.out.println("Copying....." + (a + 1) + "."
				//			+ file2.getName());
				//	sftpChannel.get(copyFrom1, copyTo1);
					// sftpChannel1.get(copyFrom1, copyTo1);
				//	sftpChannel.exit();
					// sftpChannel1.exit();
					session.disconnect();
					// session1.disconnect();
				} catch (JSchException e) {
					e.printStackTrace();
				} 
			
		System.out.println("Transfer Done !!");
		}
}