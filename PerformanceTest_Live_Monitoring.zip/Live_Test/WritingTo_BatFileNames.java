package Live_Test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.StringTokenizer;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

public class WritingTo_BatFileNames {
public static void main(String args[]) throws IOException, SftpException {
String Filepath=args[0];
	File folder = new File(Filepath + "\\FileNames");
	File[] listOfFiles = folder.listFiles();
	System.out.println("listOfFiles" + listOfFiles.length);
	int numberoffiles = listOfFiles.length;
	for (int a = 0; a <= (numberoffiles - 1); a++) {
		String[][] arrayValues = new String[50][50];
		String csvFile = Filepath + "\\FileNames\\Test" + a + ".csv";

		BufferedReader bufRdr = new BufferedReader(new FileReader(csvFile));
		String line = "";
		int row = 0;
		int col = 0;

		// read each line of text file
		while ((line = bufRdr.readLine()) != null) {
			StringTokenizer st = new StringTokenizer(line, ",");
			while (st.hasMoreTokens()) {
				// get next token and store it in the array
				arrayValues[row][col] = st.nextToken();
				col++;
			}
			row++;
			col = 0;
		}
		// close the file
		bufRdr.close();
		
		
		String hostname="";
		String application="";
		for (int i = 0; i < row; i++) {
			// int j=col;
			String copyFrom = arrayValues[i][0];
			String copyFrom1 = arrayValues[i][1];
			 hostname = arrayValues[i][2];
			String username = arrayValues[i][3];
			String password = arrayValues[i][4];
			 application = arrayValues[i][5];
			 
			 for(int k=0;k<=1;k++) {
				 
			 
			BufferedWriter output = null;
			
			File file = new File(Filepath
					+ "\\Testing.sh");
		
			output = new BufferedWriter(
					new FileWriter(file));
			String[] NewCopyFrom=copyFrom.split("/");
			String New_Aggregate_Path="";
			for(int p=0;p<NewCopyFrom.length;p++) {
				if(p==NewCopyFrom.length-1) {
					New_Aggregate_Path=New_Aggregate_Path+"/Aggregate";
				}
				New_Aggregate_Path=New_Aggregate_Path+"/"+NewCopyFrom[p];
			}
			String[] NewCopyFrom1=copyFrom1.split("/");
			String New_Aggregate_Path1="";
			for(int p=0;p<NewCopyFrom1.length;p++) {
				if(p==NewCopyFrom1.length-1) {
					New_Aggregate_Path1=New_Aggregate_Path1+"/Aggregate";
				}
				New_Aggregate_Path1=New_Aggregate_Path1+"/"+NewCopyFrom1[p];
			}
		//	System.out.println("New_Aggregate_Path::"+New_Aggregate_Path);
			//System.out.println("New_Aggregate_Path1::"+New_Aggregate_Path1);
			if(copyFrom.contains(".jtl")) {
				output.write("/home/ec2-user/jdk1.8.0_151/bin/java -jar /opt/efs/tui/jmeter/apache-jmeter-2.9/lib/ext/cmdrunner-2.0.jar --tool Reporter --generate-csv "+New_Aggregate_Path.replace(".jtl", ".csv")+" --input-jtl "+copyFrom+" --plugin-type AggregateReport");
				
				copyFrom="Null";
			}
			else if(copyFrom1.contains(".jtl")){
				output.write("/home/ec2-user/jdk1.8.0_151/bin/java -jar /opt/efs/tui/jmeter/apache-jmeter-2.9/lib/ext/cmdrunner-2.0.jar --tool Reporter --generate-csv "+New_Aggregate_Path1.replace(".jtl", ".csv")+" --input-jtl "+copyFrom1+" --plugin-type AggregateReport");
				copyFrom1="Null";
			}
			else {
				
			}
		//	output.write("clear");
			output.close();
		
	//	hostname="10.136.75.178";
			JSch jsch = new JSch();
			// JSch jsch1 = new JSch();
			Session session = null;
			// Session session1 = null;
			System.out.println("Trying to connect....." + hostname+" For Brand: "+application);
			try {
			//	jsch.addIdentity("D:\\Performance\\Services.pem");
				session = jsch.getSession("ec2-user", hostname, 22);
				
				jsch.addIdentity(Filepath+"\\Services.ppk");
				java.util.Properties config = new java.util.Properties();
				config.put("StrictHostKeyChecking", "no");
				// session1 = jsch1.getSession(username, hostname, 22);
				session.setConfig("StrictHostKeyChecking", "no");
				// session1.setConfig("StrictHostKeyChecking", "no");
			//	session.setPassword(password);
				// session1.setPassword(password);
				session.connect();
				//
				
				Channel channel = session.openChannel("sftp");
				// Channel channel1 = session1.openChannel("sftp");
				channel.connect();
				// channel1.connect();
				ChannelSftp sftpChannel = (ChannelSftp) channel;
				
				sftpChannel.put(Filepath+"\\Testing.sh", "/opt/efs/tui/jmeter/Testing.sh");
	
				
				 Channel channel1=session.openChannel("exec");
		         //   ((ChannelExec)channel).setCommand("cd "+"/opt/efs/tui/jmeter/81machine/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT/data-load-test-20191207");
		        //    ((ChannelExec)channel).setCommand("java -jar /opt/efs/tui/jmeter/81machine/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT/data-load-test-20191207/apache-jmeter-2.9/lib/ext/cmdrunner-2.0.jar --tool Reporter --generate-csv /opt/efs/tui/jmeter/81machine/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT/data-load-test-20191207/TH_aggregatereport_20191207-152838.csv --input-jtl /opt/efs/tui/jmeter/81machine/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT/data-load-test-20191207/TH_aggregatereport_20191207-152838.jtl --plugin-type AggregateReport");
		           // ((ChannelExec)channel).setCommand("sh "+"/opt/efs/tui/jmeter/81machine/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT/data-load-test-20191207/Runner.sh");
		            ChannelExec channelExe = (ChannelExec) channel1;
		            channelExe.setCommand("sh "+"/opt/efs/tui/jmeter/Testing.sh"); 
		 //           channelExe.setCommand("java -jar /opt/efs/tui/jmeter/81machine/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT/data-load-test-20191207/apache-jmeter-2.9/lib/ext/cmdrunner-2.0.jar --tool Reporter --generate-csv /opt/efs/tui/jmeter/81machine/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT/data-load-test-20191207/TH_aggregatereport_20191207-152838.csv --input-jtl /opt/efs/tui/jmeter/81machine/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT/data-load-test-20191207/TH_aggregatereport_20191207-152838.jtl --plugin-type AggregateReport");
		        
		     //       channelExe.setCommand("/home/ec2-user/jdk1.8.0_151/bin/java -jar /opt/efs/tui/jmeter/81machine/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT/data-load-test-20191207/apache-jmeter-2.9/lib/ext/cmdrunner-2.0.jar --tool Reporter --generate-csv /opt/efs/tui/jmeter/81machine/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT/data-load-test-20191207/TH_aggregatereport_20191207-152838.csv --input-jtl /opt/efs/tui/jmeter/81machine/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT/data-load-test-20191207/TH_aggregatereport_20191207-152838.jtl --plugin-type AggregateReport");
		            channel1.setInputStream(null);

		            ((ChannelExec)channel1).setErrStream(System.err);

		            InputStream in=channel1.getInputStream();

		            channel1.connect();

		          

		              if(channel1.isClosed()){
		                System.out.println("exit-status: "+channel.getExitStatus());
		            //    break;
		              }
			              channelExe.disconnect();
			            channel1.disconnect();
			            
				//	System.out.println("Copying....." + (a + 1) + "."
				//			+ file1.getName());
				//	sftpChannel.get(copyFrom, copyTo);
				//	System.out.println("Copying....." + (a + 1) + "."
				//			+ file2.getName());
				//	sftpChannel.get(copyFrom1, copyTo1);
					// sftpChannel1.get(copyFrom1, copyTo1);
				//	sftpChannel.exit();
					sftpChannel.exit();
					channel.disconnect();
					session.disconnect();
					// session1.disconnect();
				} catch (JSchException e) {
					e.printStackTrace();
				} 
			}
			
	}
	}	
			
		}
		

}

