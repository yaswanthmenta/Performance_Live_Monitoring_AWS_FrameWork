package Live_Test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import java.util.*;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import com.jcraft.jsch.ChannelSftp.LsEntry;

public class TestStertedCheck_LiveTest {
	public static void main(String args[]) throws IOException, InterruptedException, SftpException, ParseException, JSchException, AddressException, MessagingException {
		String Filepath = args[0];
		String TestStartTime="";
		String TestStartDate="";
		String TestStatedTimeDiff="";
		String SystemRunnProp="Live Test is Not Running...";
		String FinalSystemRunnProp="Live Test is Not Running...";
		int Count=0;
		int row = 0;
		int col = 0;
		String csvFile =Filepath + "\\Filenames_Standalone.csv";
		String[][] arrayValues = new String[100][100];
		int filenumber = 0;
		Scanner s= new Scanner(System.in);
		//System.out.println("Please Select Among the Below Options::");
	//	System.out.println("1. Live Monitoring in StandAlone Ec2 Machine");
		//System.out.println("2. Live Monitoring in Spot Ec2 Machine");
		int option=Integer.parseInt(args[1]);
		if(option==1) {
			System.out.println("Live Monitoring in StandAlone Ec2 Machine is Started::");
			 csvFile = Filepath + "\\Filenames_Standalone.csv";
		}
		else if(option==2){
			System.out.println("Live Monitoring in Spot Ec2 Machine is Started::");
			 csvFile = Filepath + "\\Filenames.csv";
		}
		else {
			System.out.println("Please Enter A Valid Option...!!!");
		}
		
		// System.out.println("Please enter the Executable file");
		File f1 = new File(csvFile);
		if (f1.exists()) {

			BufferedReader bufRdr = new BufferedReader(new FileReader(csvFile));
			String line = "";
		
			// read each line of text file
			while ((line = bufRdr.readLine()) != null) {
				StringTokenizer st = new StringTokenizer(line, ",");
				while (st.hasMoreTokens()) {
					// get next token and store it in the array
					arrayValues[row][col] = st.nextToken();
					col++;
				}
				row++;
				col = 0;
			}
			bufRdr.close();
		}
		String hostname = arrayValues[0][1];
		   // System.out.println(new Date());
		    
		    if(option==1) {
				 csvFile = Filepath + "\\Filenames_Standalone.csv";
				 hostname = arrayValues[0][1];
			}
			else if(option==2){
				 csvFile = Filepath + "\\Filenames.csv";
				System.out.println("Please Enter an Spot Instance IP:");
				 hostname = s.next();
			}
			else {
				System.out.println("Please Enter A Valid Option...!!!");
			}
		    s.close();
	while (true) {
    Thread.sleep(300 * 1000);
    int j=0;
	//outerloop:	for (int j = 0; j < row; j++) {
		String copyFrom = arrayValues[j][0];
	//	String hostname = arrayValues[0][1];
		String username = arrayValues[j][2];
		String password = arrayValues[j][3];
//	String password = arrayValues[1][4];
		String namingFormat="data-load-test-";
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		//System.out.println(copyFrom);
		Date date = new Date();
//	System.out.println(dateFormat.format(date));
		namingFormat=namingFormat+dateFormat.format(date);
		TestStartDate=dateFormat.format(date);
//		String application = arrayValues[1][5];
		copyFrom=copyFrom+"/"+namingFormat;
		JSch jsch = new JSch();	
		Session session = null;
		SftpATTRS attrs=null;
		//System.out.println("Trying to connect....." + hostname);
		try {
			session = jsch.getSession(username, hostname, 22);	
			jsch.addIdentity(Filepath+"\\Services.ppk");
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			session.setConfig("StrictHostKeyChecking", "no");
			session.connect();
			Channel channel = session.openChannel("sftp");
			channel.connect();
			ChannelSftp sftpChannel = (ChannelSftp) channel;
		//	System.out.println("Directory Path::"+copyFrom);
		//	sftpChannel.
			try {
			    attrs = sftpChannel.stat(copyFrom);
		//		System.out.println("copyFrom::::"+copyFrom);
				DecimalFormat two = new DecimalFormat("0.00");
			
				sftpChannel.cd(copyFrom);
				//	channelSftp.
					Vector filelist = sftpChannel.ls(copyFrom);
					String[] listoffiles = new String[filelist.size()];
					for (int i = 0; i < filelist.size(); i++) {
						LsEntry entry = (LsEntry) filelist.get(i);
				//		 System.out.println(entry.getFilename());
						//listoffiles[i] = entry.getFilename();
						
			//SendEmail.sendEmailWithAttachments(host, port, "PerfTestDetails@tui.co.uk", "fg", "subject", "message", attachFiles, Filepath);	
				if(entry.getFilename().length()>10) {
					
					SimpleDateFormat f = new SimpleDateFormat("HHmmss");
				    f.setTimeZone(TimeZone.getTimeZone("Europe/London"));
				    String Currentime=f.format(new Date());
				    //System.out.println(f.format(new Date()));
				String FilenameOftest=entry.getFilename();
				FilenameOftest=FilenameOftest.substring(entry.getFilename().length()-10, entry.getFilename().length()-4);
				TestStartTime=FilenameOftest;
				//		System.out.println("FilenameOftest::"+FilenameOftest);
				long fileSize = sftpChannel.lstat(copyFrom+"/"+entry.getFilename()).getSize();
		//		System.out.println("fileSize::::"+fileSize);
//					long fileSize1 = sftpChannel.lstat(copyFrom1).getSize();
				Thread.sleep(30*1000);
				long fileSize2 = sftpChannel.lstat(copyFrom+"/"+entry.getFilename()).getSize();
			//	System.out.println("fileSize2::::"+fileSize2);
//				long fileSize3 = sftpChannel.lstat(copyFrom1).getSize();
				SimpleDateFormat format = new SimpleDateFormat("HHmmss");
				Date date1 = format.parse(FilenameOftest);
				Date date2 = format.parse(Currentime);
				long difference = date2.getTime() - date1.getTime();
				//long timeinhours=(difference/1000)/(60*60);
				 long millis = difference;
				    String hms = String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(millis),
				            TimeUnit.MILLISECONDS.toMinutes(millis) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millis)),
				            TimeUnit.MILLISECONDS.toSeconds(millis) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis)));
			
				    TestStatedTimeDiff=hms;
				if(fileSize!=fileSize2) {
				SystemRunnProp="Live Test is Running From::"+hms+" Started @ "+TestStartTime+" BST";
					Count=Count+5;
					//Count=30;
					sftpChannel.exit();
					session.disconnect();
					break;
					//break outerloop;
				}
				else {
			//		System.out.println("No Live Test is Running..!!");
			//		System.out.println("Last Test has Started Before--"+hms);
					SystemRunnProp="Live Test is Not Running...Last Test has Started Before::"+hms;
				}
					}
				else{
				//	System.out.println("Not a valid file Checking Other Files..!!");
				}
					}
			 
		}
			catch (Exception e) {
			    System.out.println(" No Test Started Today....!!!!"+e);
			    SystemRunnProp="Live Test is Not Running...";
			}
			
			sftpChannel.exit();
			session.disconnect();
		} catch (JSchException e) {
			System.out.println(" Unable to connect to Machine....!!!!"+e);
			SystemRunnProp="Live Test is Not Running...";
			//e.printStackTrace();

		}
	
		//}
		System.out.println(" SystemRunnProp:::"+SystemRunnProp);
		System.out.println(" FinalSystemRunnProp:::"+FinalSystemRunnProp);
		if(!SystemRunnProp.substring(0, 25).equals(FinalSystemRunnProp.substring(0, 25))) {
			Count=0;
			if(FinalSystemRunnProp.contains("Live Test is Running")&&SystemRunnProp.contains("Live Test is Not Running")) {
				CopyFileNames_Without_Input.FilecopyStandAlone(Filepath,TestStartDate,TestStartTime);
				String[] strArray1 = new String[] {Filepath};
				WritingTo_BatFileNames.main(strArray1);
				//Generating_Graphs_LiveTest.main(strArray1);
				FileTransFerOverNetwork.FilCopyOverNetwork(Filepath);
			//	FileTransFerOverNetwork.GraphFileCopyOverNetwork(Filepath);
			//	GraphsToPdf.main(strArray1);
				BufferedWriter output = null;
				File file2 = new File(Filepath+"\\New_Jars_Perf_Exec\\LiveTestBatFile.bat");
				output = new BufferedWriter(new FileWriter(file2));
			/*	output.write("set projectpath="+Filepath+"\\ReportAutomation\\PerformanceReport");
				output.newLine();		
				output.write("cd %projectpath%");
						output.newLine();
						output.write("javac -d bin -cp \"Libraries\\*\" src\\reportformation\\PerformanceVersionTwoJtlToCSV.java");
						output.newLine();
						output.write("java -Xmx1024m -cp \".;bin;Libraries\\*\" reportformation.PerformanceVersionTwoJtlToCSV "+Filepath+"/ReportAutomation/Reports/ "+Filepath+"/ReportAutomation/ "+Filepath+"\\CompleteAuto\\apache-jmeter-2.9\\");
						output.newLine();*/
				output.write("set projectpath="+Filepath+"\\ReportAutomation\\PerformanceReport");
				output.newLine();
				output.write("cd %projectpath%");
				output.newLine();
				output.write("javac -d bin -cp \"Libraries\\*\" src\\reportformation\\PerformanceVersionTwoFinal.java");
				output.newLine();
				output.write("java -Xmx1024m -cp \".;bin;Libraries\\*\" reportformation.PerformanceVersionTwoFinal "+Filepath+"/ReportAutomation/Reports/ "+Filepath+"/ReportAutomation/");
				output.newLine();
						output.write("set projectpath="+Filepath+"\\New_Jars_Perf_Exec");
						output.newLine();
						output.write("cd %projectpath%");
						output.newLine();
		     			output.write( "java -jar LiveTest_ReadingAggregates.jar "+Filepath+" "+"Final_Report"+" "+TestStartTime);
		     			output.newLine();
						output.write( "set projectpath="+Filepath+"\\New_Jars_Perf_Exec");
						output.newLine();
						output.write( "cd %projectpath%");
						output.newLine();
						output.write( "java -jar SendEmail_LiveTest.jar "+Filepath);
						output.newLine();
						output.write("exit");
				
				output.close();
				
				try {
			        Process p =  Runtime.getRuntime().exec("cmd /c start "+Filepath+"\\New_Jars_Perf_Exec\\LiveTestBatFile.bat\"") ;
				} catch (IOException ex) {
			System.out.println("Exception::"+ex);
				}
			}
			else {
			System.out.println(SystemRunnProp);
			SendEmail_LiveTest.sendEmail("10.33.200.35", "22", "LivePerfTestStatus@tui.co.uk", "Nopassword", SystemRunnProp,"Hi Team,     "+SystemRunnProp, Filepath);
		}
		}
		else {
			if(Count%30==0 && !SystemRunnProp.contains("Not") ) {
				Count=0;
				if(option==1) {
				CopyFileNames_Without_Input.FilecopyStandAlone(Filepath,TestStartDate,TestStartTime);
				String[] strArray1 = new String[] {Filepath};
				WritingTo_BatFileNames.main(strArray1);
				//Generating_Graphs_LiveTest.main(strArray1);
				FileTransFerOverNetwork.FilCopyOverNetwork(Filepath);
				//FileTransFerOverNetwork.GraphFileCopyOverNetwork(Filepath);
			//	GraphsToPdf.main(strArray1);
				BufferedWriter output = null;
				File file2 = new File(Filepath+"\\New_Jars_Perf_Exec\\LiveTestBatFile.bat");
				output = new BufferedWriter(new FileWriter(file2));
			/*	output.write("set projectpath="+Filepath+"\\ReportAutomation\\PerformanceReport");
				output.newLine();		
				output.write("cd %projectpath%");
						output.newLine();
						output.write("javac -d bin -cp \"Libraries\\*\" src\\reportformation\\PerformanceVersionTwoJtlToCSV.java");
						output.newLine();
						output.write("java -Xmx1024m -cp \".;bin;Libraries\\*\" reportformation.PerformanceVersionTwoJtlToCSV "+Filepath+"/ReportAutomation/Reports/ "+Filepath+"/ReportAutomation/ "+Filepath+"\\CompleteAuto\\apache-jmeter-2.9\\");
						output.newLine();*/
				output.write("set projectpath="+Filepath+"\\ReportAutomation\\PerformanceReport");
				output.newLine();
				output.write("cd %projectpath%");
				output.newLine();
				output.write("javac -d bin -cp \"Libraries\\*\" src\\reportformation\\PerformanceVersionTwoFinal.java");
				output.newLine();
				output.write("java -Xmx1024m -cp \".;bin;Libraries\\*\" reportformation.PerformanceVersionTwoFinal "+Filepath+"/ReportAutomation/Reports/ "+Filepath+"/ReportAutomation/");
				output.newLine();
						output.write("set projectpath="+Filepath+"\\New_Jars_Perf_Exec");
						output.newLine();
						output.write("cd %projectpath%");
						output.newLine();
		     			output.write( "java -jar LiveTest_ReadingAggregates.jar "+Filepath+" "+TestStatedTimeDiff+" "+TestStartTime);
		     			output.newLine();
						output.write( "set projectpath="+Filepath+"\\New_Jars_Perf_Exec");
						output.newLine();
						output.write( "cd %projectpath%");
						output.newLine();
						output.write( "java -jar SendEmail_LiveTest.jar "+Filepath);
						output.newLine();
						output.write("exit");
				
				output.close();
				
				try {
			        Process p =  Runtime.getRuntime().exec("cmd /c start "+Filepath+"\\New_Jars_Perf_Exec\\LiveTestBatFile.bat\"") ;
				} catch (IOException ex) {
			System.out.println("Exception::"+ex);
				}
				}
				else if(option==2) {
					CopyFileNames_Without_Input.FilecopySpotMachine(Filepath, TestStartDate, TestStartTime, hostname);
					String[] strArray1 = new String[] {Filepath};
					WritingTo_BatFileNames.main(strArray1);
				//	Generating_Graphs_LiveTest.main(strArray1);
					FileTransFerOverNetwork.FilCopyOverNetwork(Filepath);
				//	FileTransFerOverNetwork.GraphFileCopyOverNetwork(Filepath);
				//	GraphsToPdf.main(strArray1);
					BufferedWriter output = null;
					File file2 = new File(Filepath+"\\New_Jars_Perf_Exec\\LiveTestBatFile.bat");
					output = new BufferedWriter(new FileWriter(file2));
					output.write("set projectpath="+Filepath+"\\ReportAutomation\\PerformanceReport");
					output.newLine();
					output.write("cd %projectpath%");
					output.newLine();
					output.write("javac -d bin -cp \"Libraries\\*\" src\\reportformation\\PerformanceVersionTwoFinal.java");
					output.newLine();
					output.write("java -Xmx1024m -cp \".;bin;Libraries\\*\" reportformation.PerformanceVersionTwoFinal "+Filepath+"/ReportAutomation/Reports/ "+Filepath+"/ReportAutomation/");
					output.newLine();
					output.write("set projectpath="+Filepath+"\\New_Jars_Perf_Exec");
					output.newLine();
					output.write("cd %projectpath%");
					output.newLine();
	     			output.write( "java -jar LiveTest_ReadingAggregates.jar "+Filepath+" "+TestStatedTimeDiff+" "+TestStartTime);
	     			output.newLine();
					output.write( "set projectpath="+Filepath+"\\New_Jars_Perf_Exec");
					output.newLine();
					output.write( "cd %projectpath%");
					output.newLine();
					output.write( "java -jar SendEmail_LiveTest.jar "+Filepath);
					output.newLine();
					output.write("exit");
	       			output.close();
			
					try {
				        Process p =  Runtime.getRuntime().exec("cmd /c start "+Filepath+"\\New_Jars_Perf_Exec\\LiveTestBatFile.bat\"") ;
					} catch (IOException ex) {
						System.out.println("Exception::"+ex);
				
					}
					
				}
				else{
					System.out.println("Enter a Valid Option...!!!");
				}
				System.out.println("Every 30 Mins Report..");
				
			}
			else {
				System.out.println("5 Minutes Done..");
			}
		}
		FinalSystemRunnProp=SystemRunnProp;
		}
	}
		
	
	}