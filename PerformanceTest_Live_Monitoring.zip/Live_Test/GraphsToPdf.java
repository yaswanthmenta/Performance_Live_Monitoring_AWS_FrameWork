package Live_Test;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

public class GraphsToPdf {
	  public static void main(String[] args) {
	    Document document = new Document();
	    
		String Filepath=args[0];
		List<String> results = new ArrayList<String>();
		File folder = new File(Filepath+"\\Graphs");
		File[] listOfFiles = folder.listFiles();
		//If this pathname does not denote a directory, then listFiles() returns null. 
	//System.out.println("files"+listOfFiles);
		for (File file : listOfFiles) {
		    if (file.isFile() && file.getName().contains("png") ) {
		        results.add(file.getName());
		    }
		}
	    
	    
	    
	    String output = Filepath+"\\ReportAutomation\\ResultFolder\\AggregateGraphs.pdf";
	    try {
	      FileOutputStream fos = new FileOutputStream(output);
	      PdfWriter writer = PdfWriter.getInstance(document, fos);
	      writer.open();
	      document.open();
	      for(int i=0;i<results.size();i++)
	      {
	    	  String input = Filepath+"\\Graphs\\"+results.get(i); // .gif and .jpg are ok too!
	          
	    	  String[] name=results.get(i).split("_");
	    	   Paragraph p;
	    	   Font normal = new Font(FontFamily.TIMES_ROMAN, 12);
	           Font bold = new Font(FontFamily.TIMES_ROMAN, 12, Font.BOLD);
	           boolean title = true;
	           p = new Paragraph(name[0], title ? bold : normal);
	            p.setAlignment(Element.ALIGN_JUSTIFIED);
	    	//  document.
	            document.addCreationDate();
	            document.setMargins(36, 72, 108, 180);
	            document.setMarginMirroring(false);
	            // step 3
	            document.open();
	            // step 4
	            Rectangle rect= new Rectangle(36,108);
	            rect.enableBorderSide(1);
	            rect.enableBorderSide(2);
	            rect.enableBorderSide(4);
	            rect.enableBorderSide(8);
	            rect.setBorder(2);
	            rect.setBorderColor(BaseColor.BLACK);
	            document.add(rect);
	            
	            
	           // document.setMargins(10, 10, 10, 10);
	         document.add(p);
	    	  Image img = Image.getInstance(input);
	    	      img.scalePercent(60);
	    	      document.add(img);
	             document.newPage();
	      
	      }  // document.add(Image.getInstance(input).scaleAbsolute(50, 50));
	      document.close();
	      writer.close();
	    }
	    catch (Exception e) {
	      e.printStackTrace();
	    }
	  }
	}