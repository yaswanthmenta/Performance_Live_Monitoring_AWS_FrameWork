package Live_Test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.StringTokenizer;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

public class FileTransFerOverNetwork {
	public static void main(String args[]) throws IOException, InterruptedException {
		// Scanner sc=new Scanner(System.in);
		// String Filepath=sc.next();
		String Filepath = args[0];
		File file = new File(Filepath
				+ "\\ReportAutomation\\Reports\\PerformanceReport-20161103");
		String[] myFiles;
		if (file.isDirectory()) {
			myFiles = file.list();
			for (int i = 0; i < myFiles.length; i++) {
				File myFile = new File(file, myFiles[i]);
				myFile.delete();
			}
		}

		// String[][] arrayValues = new String[39][39];

		// File file = new File("exported_file.csv");

		File folder = new File(Filepath + "\\FileNames");
		File[] listOfFiles = folder.listFiles();
		System.out.println("listOfFiles" + listOfFiles.length);
		int numberoffiles = listOfFiles.length;
		for (int a = 0; a <= (numberoffiles - 1); a++) {
			String[][] arrayValues = new String[50][50];
			String csvFile = Filepath + "\\FileNames\\Test" + a + ".csv";

			BufferedReader bufRdr = new BufferedReader(new FileReader(csvFile));
			String line = "";
			int row = 0;
			int col = 0;

			// read each line of text file
			while ((line = bufRdr.readLine()) != null) {
				StringTokenizer st = new StringTokenizer(line, ",");
				while (st.hasMoreTokens()) {
					// get next token and store it in the array
					arrayValues[row][col] = st.nextToken();
					col++;
				}
				row++;
				col = 0;
			}
			// close the file
			bufRdr.close();

			/*
			 * for(int k = 0; k < row; k++){ for(int l = 0; l < 5; l++){
			 * System.out.println(arrayValues[k][l]+" "+k+l); } }
			 */

			for (int i = 0; i < row; i++) {
				// int j=col;
				String copyFrom = arrayValues[i][0];
				String copyFrom1 = arrayValues[i][1];
				String hostname = arrayValues[i][2];
				String username = arrayValues[i][3];
				String password = arrayValues[i][4];
				String application = arrayValues[i][5];
				/*
				 * if(application.equals("THOther")){
				 * copyFrom=copyFrom.replace("TH_errors", "THOther_errors");
				 * copyFrom=copyFrom.replace("TH_aggregatereport",
				 * "THOther_aggregatereport");
				 * copyFrom1=copyFrom1.replace("TH_errors", "THOther_errors");
				 * copyFrom1=copyFrom1.replace("TH_aggregatereport",
				 * "THOther_aggregatereport"); }
				 */
				if(copyFrom.contains(".jtl")) {
					String[] NewCopyFrom=copyFrom.split("/");
					String New_Aggregate_Path="";
					for(int p=0;p<NewCopyFrom.length;p++) {
						if(p==NewCopyFrom.length-1) {
							New_Aggregate_Path=New_Aggregate_Path+"/Aggregate";
						}
						New_Aggregate_Path=New_Aggregate_Path+"/"+NewCopyFrom[p];
					}
					copyFrom=New_Aggregate_Path;
					}
					
					if(copyFrom1.contains(".jtl")) {
						String[] NewCopyFrom1=copyFrom1.split("/");
						String New_Aggregate_Path1="";
						for(int p=0;p<NewCopyFrom1.length;p++) {
							if(p==NewCopyFrom1.length-1) {
								New_Aggregate_Path1=New_Aggregate_Path1+"/Aggregate";
							}
							New_Aggregate_Path1=New_Aggregate_Path1+"/"+NewCopyFrom1[p];
						}
						copyFrom1=New_Aggregate_Path1;
						}
				
				copyFrom=copyFrom.replace(".jtl", ".csv");
				copyFrom1=copyFrom1.replace(".jtl", ".csv");
				
				
				
				File file1 = new File(copyFrom);
				File file2 = new File(copyFrom1);

				String copyTo = Filepath
						+ "\\ReportAutomation\\Reports\\PerformanceReport-20161103\\"
						+ file1.getName();
				String copyTo1 = Filepath
						+ "\\ReportAutomation\\Reports\\PerformanceReport-20161103\\"
						+ file2.getName();
				
				if (application.equals("THOther")) {
					copyTo = copyTo.replace("TH_errors", "THOther_errors");
					copyTo = copyTo.replace("TH_aggregatereport",
							"THOther_aggregatereport");
					copyTo1 = copyTo1.replace("TH_errors", "THOther_errors");
					copyTo1 = copyTo1.replace("TH_aggregatereport",
							"THOther_aggregatereport");
				}
				copyTo=copyTo.replace(".jtl", ".csv");
				copyTo1=copyTo1.replace(".jtl", ".csv");
				// System.out.println("file2.getName()"+file2.getName());
				// double filelength1= file1.length();
				// double filelength1= file1.length()/(1024*1024);
				// double filelength2= file2.length();
				// double filelength2= file2.length()/(1024*1024);
				JSch jsch = new JSch();
				// JSch jsch1 = new JSch();
				Session session = null;
				// Session session1 = null;
				System.out.println("Trying to connect....." + hostname);
				try {
				//	jsch.addIdentity("D:\\Performance\\Services.pem");
					session = jsch.getSession(username, hostname, 22);
					
					jsch.addIdentity(Filepath+"\\Services.ppk");
					java.util.Properties config = new java.util.Properties();
					config.put("StrictHostKeyChecking", "no");
					// session1 = jsch1.getSession(username, hostname, 22);
					session.setConfig("StrictHostKeyChecking", "no");
					// session1.setConfig("StrictHostKeyChecking", "no");
				//	session.setPassword(password);
					// session1.setPassword(password);
					session.connect();
					// session1.connect();
					
					Channel channel = session.openChannel("sftp");
					// Channel channel1 = session1.openChannel("sftp");
					channel.connect();
					// channel1.connect();
					ChannelSftp sftpChannel = (ChannelSftp) channel;
					// ChannelSftp sftpChannel1 = (ChannelSftp) channel1;
					if(i==0) {
					long fileSize = sftpChannel.lstat(copyFrom).getSize();
				//	System.out.println("FileSize"+fileSize);
					Thread.sleep(10000);
					long fileSize2 = sftpChannel.lstat(copyFrom).getSize();
				//	System.out.println("FileSize After 10 Sec:"+fileSize2);
					if(fileSize!=fileSize2) {
						System.out.println("Test is still running....!!!!");
					}
					else {
						System.out.println("No Live Test is Running..!!");
					}
					}
					System.out.println("Copying....." + (a + 1) + "."
							+ file1.getName());
					sftpChannel.get(copyFrom, copyTo);
					System.out.println("Copying....." + (a + 1) + "."
							+ file2.getName());
					sftpChannel.get(copyFrom1, copyTo1);
					// sftpChannel1.get(copyFrom1, copyTo1);
					sftpChannel.exit();
					// sftpChannel1.exit();
					session.disconnect();
					// session1.disconnect();
				} catch (JSchException e) {
					e.printStackTrace();
				} catch (SftpException e) {
					e.printStackTrace();
				}
			}
		}

		System.out.println("Transfer Done !!");
	}
public static void FilCopyOverNetwork(String Filepath) throws IOException, InterruptedException {
	// Scanner sc=new Scanner(System.in);
	// String Filepath=sc.next();
	//String Filepath = args[0];
	File file = new File(Filepath
			+ "\\ReportAutomation\\Reports\\PerformanceReport-20161103");
	String[] myFiles;
	if (file.isDirectory()) {
		myFiles = file.list();
		for (int i = 0; i < myFiles.length; i++) {
			File myFile = new File(file, myFiles[i]);
			myFile.delete();
		}
	}

	// String[][] arrayValues = new String[39][39];

	// File file = new File("exported_file.csv");

	File folder = new File(Filepath + "\\FileNames");
	File[] listOfFiles = folder.listFiles();
	System.out.println("listOfFiles" + listOfFiles.length);
	int numberoffiles = listOfFiles.length;
	for (int a = 0; a <= (numberoffiles - 1); a++) {
		String[][] arrayValues = new String[50][50];
		String csvFile = Filepath + "\\FileNames\\Test" + a + ".csv";

		BufferedReader bufRdr = new BufferedReader(new FileReader(csvFile));
		String line = "";
		int row = 0;
		int col = 0;

		// read each line of text file
		while ((line = bufRdr.readLine()) != null) {
			StringTokenizer st = new StringTokenizer(line, ",");
			while (st.hasMoreTokens()) {
				// get next token and store it in the array
				arrayValues[row][col] = st.nextToken();
				col++;
			}
			row++;
			col = 0;
		}
		// close the file
		bufRdr.close();

		/*
		 * for(int k = 0; k < row; k++){ for(int l = 0; l < 5; l++){
		 * System.out.println(arrayValues[k][l]+" "+k+l); } }
		 */

		for (int i = 0; i < row; i++) {
			// int j=col;
			String copyFrom = arrayValues[i][0];
			String copyFrom1 = arrayValues[i][1];
			String hostname = arrayValues[i][2];
			String username = arrayValues[i][3];
			String password = arrayValues[i][4];
			String application = arrayValues[i][5];
			/*
			 * if(application.equals("THOther")){
			 * copyFrom=copyFrom.replace("TH_errors", "THOther_errors");
			 * copyFrom=copyFrom.replace("TH_aggregatereport",
			 * "THOther_aggregatereport");
			 * copyFrom1=copyFrom1.replace("TH_errors", "THOther_errors");
			 * copyFrom1=copyFrom1.replace("TH_aggregatereport",
			 * "THOther_aggregatereport"); }
			 */
			if(copyFrom.contains(".jtl")) {
			String[] NewCopyFrom=copyFrom.split("/");
			String New_Aggregate_Path="";
			for(int p=0;p<NewCopyFrom.length;p++) {
				if(p==NewCopyFrom.length-1) {
					New_Aggregate_Path=New_Aggregate_Path+"/Aggregate";
				}
				New_Aggregate_Path=New_Aggregate_Path+"/"+NewCopyFrom[p];
			}
			copyFrom=New_Aggregate_Path;
			}
			
			if(copyFrom1.contains(".jtl")) {
				String[] NewCopyFrom1=copyFrom1.split("/");
				String New_Aggregate_Path1="";
				for(int p=0;p<NewCopyFrom1.length;p++) {
					if(p==NewCopyFrom1.length-1) {
						New_Aggregate_Path1=New_Aggregate_Path1+"/Aggregate";
					}
					New_Aggregate_Path1=New_Aggregate_Path1+"/"+NewCopyFrom1[p];
				}
				copyFrom1=New_Aggregate_Path1;
				}
			
			File file1 = new File(copyFrom);
			File file2 = new File(copyFrom1);

			String copyTo = Filepath
					+ "\\ReportAutomation\\Reports\\PerformanceReport-20161103\\"
					+ file1.getName();
			String copyTo1 = Filepath
					+ "\\ReportAutomation\\Reports\\PerformanceReport-20161103\\"
					+ file2.getName();
			
			if (application.equals("THOther")) {
				copyTo = copyTo.replace("TH_errors", "THOther_errors");
				copyTo = copyTo.replace("TH_aggregatereport",
						"THOther_aggregatereport");
				copyTo1 = copyTo1.replace("TH_errors", "THOther_errors");
				copyTo1 = copyTo1.replace("TH_aggregatereport",
						"THOther_aggregatereport");
			}
			// System.out.println("file2.getName()"+file2.getName());
			// double filelength1= file1.length();
			// double filelength1= file1.length()/(1024*1024);
			// double filelength2= file2.length();
			copyFrom=copyFrom.replace(".jtl", ".csv");
			copyFrom1=copyFrom1.replace(".jtl", ".csv");
			copyTo=copyTo.replace(".jtl", ".csv");
			copyTo1=copyTo1.replace(".jtl", ".csv");
			
			// double filelength2= file2.length()/(1024*1024);
			JSch jsch = new JSch();
			// JSch jsch1 = new JSch();
			Session session = null;
			// Session session1 = null;
			System.out.println("Trying to connect....." + hostname);
			try {
			//	jsch.addIdentity("D:\\Performance\\Services.pem");
				session = jsch.getSession(username, hostname, 22);
				
				jsch.addIdentity(Filepath+"\\Services.ppk");
				java.util.Properties config = new java.util.Properties();
				config.put("StrictHostKeyChecking", "no");
				// session1 = jsch1.getSession(username, hostname, 22);
				session.setConfig("StrictHostKeyChecking", "no");
				// session1.setConfig("StrictHostKeyChecking", "no");
			//	session.setPassword(password);
				// session1.setPassword(password);
				session.connect();
				// session1.connect();

				Channel channel = session.openChannel("sftp");
				// Channel channel1 = session1.openChannel("sftp");
				channel.connect();
				// channel1.connect();
				ChannelSftp sftpChannel = (ChannelSftp) channel;
				// ChannelSftp sftpChannel1 = (ChannelSftp) channel1;
				if(i==0) {
				long fileSize = sftpChannel.lstat(copyFrom).getSize();
			//	System.out.println("FileSize"+fileSize);
				Thread.sleep(10000);
				long fileSize2 = sftpChannel.lstat(copyFrom).getSize();
			//	System.out.println("FileSize After 10 Sec:"+fileSize2);
				if(fileSize!=fileSize2) {
					System.out.println("Test is still running....!!!!");
				}
				else {
					System.out.println("No Live Test is Running..!!");
				}
				}
				System.out.println("Copying....." + (a + 1) + "."
						+ file1.getName());
				sftpChannel.get(copyFrom, copyTo);
				System.out.println("Copying....." + (a + 1) + "."
						+ file2.getName());
				sftpChannel.get(copyFrom1, copyTo1);
				// sftpChannel1.get(copyFrom1, copyTo1);
				sftpChannel.exit();
				// sftpChannel1.exit();
				session.disconnect();
				// session1.disconnect();
			} catch (JSchException e) {
				e.printStackTrace();
			} catch (SftpException e) {
				e.printStackTrace();
			}
		}
	}

	System.out.println("Transfer Done !!");
}


public static void GraphFileCopyOverNetwork(String Filepath) throws IOException, InterruptedException {
	// Scanner sc=new Scanner(System.in);
	// String Filepath=sc.next();
	//String Filepath = args[0];
	File file = new File(Filepath
			+ "\\Graphs");
	String[] myFiles;
	if (file.isDirectory()) {
		myFiles = file.list();
		for (int i = 0; i < myFiles.length; i++) {
			File myFile = new File(file, myFiles[i]);
			myFile.delete();
		}
	}

	// String[][] arrayValues = new String[39][39];

	// File file = new File("exported_file.csv");

	File folder = new File(Filepath + "\\FileNames");
	File[] listOfFiles = folder.listFiles();
	System.out.println("listOfFiles" + listOfFiles.length);
	int numberoffiles = listOfFiles.length;
	for (int a = 0; a <= (numberoffiles - 1); a++) {
		String[][] arrayValues = new String[50][50];
		String csvFile = Filepath + "\\FileNames\\Test" + a + ".csv";

		BufferedReader bufRdr = new BufferedReader(new FileReader(csvFile));
		String line = "";
		int row = 0;
		int col = 0;

		// read each line of text file
		while ((line = bufRdr.readLine()) != null) {
			StringTokenizer st = new StringTokenizer(line, ",");
			while (st.hasMoreTokens()) {
				// get next token and store it in the array
				arrayValues[row][col] = st.nextToken();
				col++;
			}
			row++;
			col = 0;
		}
		// close the file
		bufRdr.close();

		/*
		 * for(int k = 0; k < row; k++){ for(int l = 0; l < 5; l++){
		 * System.out.println(arrayValues[k][l]+" "+k+l); } }
		 */

		for (int i = 0; i < row; i++) {
			// int j=col;
			String copyFrom = arrayValues[i][0];
			String copyFrom1 = arrayValues[i][1];
			String hostname = arrayValues[i][2];
			String username = arrayValues[i][3];
			String password = arrayValues[i][4];
			String application = arrayValues[i][5];
			/*
			 * if(application.equals("THOther")){
			 * copyFrom=copyFrom.replace("TH_errors", "THOther_errors");
			 * copyFrom=copyFrom.replace("TH_aggregatereport",
			 * "THOther_aggregatereport");
			 * copyFrom1=copyFrom1.replace("TH_errors", "THOther_errors");
			 * copyFrom1=copyFrom1.replace("TH_aggregatereport",
			 * "THOther_aggregatereport"); }
			 */
			if(copyFrom.contains(".jtl")) {
			String[] NewCopyFrom=copyFrom.split("/");
			String New_Aggregate_Path="";
			for(int p=0;p<NewCopyFrom.length;p++) {
				if(p==NewCopyFrom.length-1) {
					New_Aggregate_Path=New_Aggregate_Path+"/Graphs";
				}
				New_Aggregate_Path=New_Aggregate_Path+"/"+NewCopyFrom[p];
			}
			copyFrom=New_Aggregate_Path;
			}
			
			if(copyFrom1.contains(".jtl")) {
				String[] NewCopyFrom1=copyFrom1.split("/");
				String New_Aggregate_Path1="";
				for(int p=0;p<NewCopyFrom1.length;p++) {
					if(p==NewCopyFrom1.length-1) {
						New_Aggregate_Path1=New_Aggregate_Path1+"/Graphs";
					}
					New_Aggregate_Path1=New_Aggregate_Path1+"/"+NewCopyFrom1[p];
				}
				copyFrom1=New_Aggregate_Path1;
				}
			
			File file1 = new File(copyFrom);
			File file2 = new File(copyFrom1);

			String copyTo = Filepath
					+ "\\Graphs\\"
					+ file1.getName();
			String copyTo1 = Filepath
					+ "\\Graphs\\"
					+ file2.getName();
			
			if (application.equals("THOther")) {
				copyTo = copyTo.replace("TH_errors", "THOther_errors");
				copyTo = copyTo.replace("TH_aggregatereport",
						"THOther_aggregatereport");
				copyTo1 = copyTo1.replace("TH_errors", "THOther_errors");
				copyTo1 = copyTo1.replace("TH_aggregatereport",
						"THOther_aggregatereport");
			}
			// System.out.println("file2.getName()"+file2.getName());
			// double filelength1= file1.length();
			// double filelength1= file1.length()/(1024*1024);
			// double filelength2= file2.length();
			copyFrom=copyFrom.replace(".jtl", ".png");
			copyFrom1=copyFrom1.replace(".jtl", ".png");
			copyTo=copyTo.replace(".jtl", ".png");
			copyTo1=copyTo1.replace(".jtl", ".png");
			
			// double filelength2= file2.length()/(1024*1024);
			JSch jsch = new JSch();
			// JSch jsch1 = new JSch();
			Session session = null;
			// Session session1 = null;
			System.out.println("Trying to connect....." + hostname);
			try {
			//	jsch.addIdentity("D:\\Performance\\Services.pem");
				session = jsch.getSession(username, hostname, 22);
				
				jsch.addIdentity(Filepath+"\\Services.ppk");
				java.util.Properties config = new java.util.Properties();
				config.put("StrictHostKeyChecking", "no");
				// session1 = jsch1.getSession(username, hostname, 22);
				session.setConfig("StrictHostKeyChecking", "no");
				// session1.setConfig("StrictHostKeyChecking", "no");
			//	session.setPassword(password);
				// session1.setPassword(password);
				session.connect();
				// session1.connect();

				Channel channel = session.openChannel("sftp");
				// Channel channel1 = session1.openChannel("sftp");
				channel.connect();
				// channel1.connect();
				ChannelSftp sftpChannel = (ChannelSftp) channel;
				// ChannelSftp sftpChannel1 = (ChannelSftp) channel1;
				if(i==0) {
				long fileSize = sftpChannel.lstat(copyFrom).getSize();
			//	System.out.println("FileSize"+fileSize);
				Thread.sleep(10000);
				long fileSize2 = sftpChannel.lstat(copyFrom).getSize();
			//	System.out.println("FileSize After 10 Sec:"+fileSize2);
				if(fileSize!=fileSize2) {
					System.out.println("Test is still running....!!!!");
				}
				else {
					System.out.println("No Live Test is Running..!!");
				}
				}
				System.out.println("Copying....." + (a + 1) + "."
						+ file1.getName());
				sftpChannel.get(copyFrom, copyTo);
				System.out.println("Copying....." + (a + 1) + "."
						+ file2.getName());
				sftpChannel.get(copyFrom1, copyTo1);
				// sftpChannel1.get(copyFrom1, copyTo1);
				sftpChannel.exit();
				// sftpChannel1.exit();
				session.disconnect();
				// session1.disconnect();
			} catch (JSchException e) {
				e.printStackTrace();
			} catch (SftpException e) {
				e.printStackTrace();
			}
		}
	}

	System.out.println("Transfer Done !!");
}



}