package Live_Test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Date;
import java.util.Properties;
import java.util.Scanner;

import javax.mail.Address;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class SendEmail_LiveTest {

	public static void sendEmailWithAttachments(String host, String port,
			final String userName, final String password, String subject,
			String message, String[] attachFiles, String Filepath)
			throws AddressException, MessagingException, IOException {
		// sets SMTP server properties

		File folder = new File(Filepath + "\\ReportAutomation\\ResultFolder");
		File[] listOfFiles = folder.listFiles();
		System.out.println("listOfFiles" + listOfFiles.length);

		Properties properties = new Properties();
		properties.put("mail.smtp.host", host);
		properties.put("mail.smtp.port", port);
	//	properties.put("mail.smtp.auth", "true");
		//properties.put("mail.smtp.starttls.enable", "true");
		properties.put("mail.user", userName);
		properties.put("mail.password", password);
		 Session session = Session.getDefaultInstance(properties);
		// creates a new session with an authenticator
	/*	Authenticator auth = new Authenticator() {
			public PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(userName, password);
			}
		};*/
	//	Session session = Session.getInstance(properties, auth);
		String csvFile = Filepath + "\\Emails.txt";
		BufferedReader bufRdr = new BufferedReader(new FileReader(csvFile));
		String line = "";
		line = bufRdr.readLine();
		// System.out.println("Line"+line);
		// String recipient = "saiyaswanth.m@sonata-software.com";
		String[] recipientList = line.split(",");
		InternetAddress[] recipientAddress = new InternetAddress[recipientList.length];
		int counter = 0;
		for (String recipient1 : recipientList) {
			recipientAddress[counter] = new InternetAddress(recipient1.trim());
			counter++;
		}
		// Address[] recipientAddress1={ new
		// InternetAddress("yaswanth.menta@gmail.com") };
		// message.setRecipients(Message.RecipientType.TO, recipientAddress);

		// creates a new e-mail message
		Message msg = new MimeMessage(session);

		msg.setFrom(new InternetAddress(userName));
		// InternetAddress[] toAddresses = { new InternetAddress(toAddress) };
		msg.setRecipients(Message.RecipientType.TO, recipientAddress);
		// msg.setRecipients(Message.RecipientType.CC, recipientAddress1);
		msg.setSubject(subject);
		msg.setSentDate(new Date());

		// creates message part
		MimeBodyPart messageBodyPart = new MimeBodyPart();
		messageBodyPart.setContent(message, "text/html");

		// creates multi-part
		Multipart multipart = new MimeMultipart();
		multipart.addBodyPart(messageBodyPart);

		// adds attachments
		if (attachFiles != null && attachFiles.length > 0) {
			for (String filePath : attachFiles) {
				MimeBodyPart attachPart = new MimeBodyPart();

				try {
					attachPart.attachFile(filePath);
				} catch (IOException ex) {
					ex.printStackTrace();
				}

				multipart.addBodyPart(attachPart);
			}
		}

		// sets the multi-part as e-mail's content
		msg.setContent(multipart);

		// sends the e-mail
		Transport.send(msg);

	}

	public static void main(String[] args) throws IOException {
		// Scanner sc=new Scanner(System.in);
		// String Filepath=sc.next();
		String Filepath = args[0];
		// String mailTo = args[1];
		File folder = new File(Filepath + "\\ReportAutomation\\ResultFolder");
		File[] listOfFiles = folder.listFiles();
		// System.out.println("listOfFiles"+listOfFiles.length);
		for (File file : listOfFiles) {
			if (file.isFile()) {
				System.out.println(file.getName());
				// System.out.println("listOfFiles"+listOfFiles.length);
			}
			// System.out.println("listOfFiles"+listOfFiles.length);
		}
		// SMTP info
		String host = "10.33.200.35";
		String port = "25";
		String mailFrom = "LivePerfTestStatus@tui.co.uk";
		String password = "ssltuiodc@1";

		// message info
		// String mailTo = "saiyaswanth.m@sonata-software.com";
		String subject = "Live Reporting";
	//	String message = "Please Find the Attachments of SLA & Error Reports.";
		BufferedReader reader = new BufferedReader(new FileReader(Filepath+"\\final\\PerformanceSummaryReport.html"));
		StringBuilder stringBuilder = new StringBuilder();
		String line = null;
		String ls = System.getProperty("line.separator");
		while ((line = reader.readLine()) != null) {
			stringBuilder.append(line);
			stringBuilder.append(ls);
		}
		// delete the last new line separator
		stringBuilder.deleteCharAt(stringBuilder.length() - 1);
		reader.close();

		String message = stringBuilder.toString();
		
		// attachments
		String[] attachFiles = new String[listOfFiles.length];
		attachFiles[0] = Filepath + "\\ReportAutomation\\ResultFolder\\"
				+ listOfFiles[0].getName();
		if (listOfFiles.length >= 2) {
			attachFiles[1] = Filepath + "\\ReportAutomation\\ResultFolder\\"
					+ listOfFiles[1].getName();
		}
		try {
			sendEmailWithAttachments(host, port, mailFrom, password, subject,
				message, attachFiles, Filepath);
		//	sendEmail(host, port, "LiverPerfTestStat@tui.co.uk", password, subject, message, Filepath);
			System.out.println("Email sent.");
		} catch (Exception ex) {
			System.out
					.println("Could not send email.Please pickup Results from"
							+ Filepath + "\\ReportAutomation\\ResultFolder"+ex);
			ex.printStackTrace();
		}
	}
	public static void sendEmail(String host, String port,
			final String userName, final String password, String subject,
			String message, String Filepath)
			throws AddressException, MessagingException, IOException {
		// sets SMTP server properties
		// String recipient = "recipient@gmail.com"; 
		  
	      // email ID of  Sender. 
	     // String sender = "sender@gmail.com"; 
	  
	      // using host as localhost 
	     // String host = "127.0.0.1"; 
	  
	      // Getting system properties 
	      Properties properties = System.getProperties(); 
	  
	      // Setting up mail server 
	      properties.setProperty("mail.smtp.host", host); 
	  
	      // creating session object to get properties 
	      Session session = Session.getDefaultInstance(properties); 
	  
	      try 
	      { 
	         // MimeMessage object. 
	         MimeMessage messag = new MimeMessage(session); 
	         messag.setContent(message, "text/html");
	         // Set From Field: adding senders email to from field. 
	         messag.setFrom(new InternetAddress(userName)); 
	  
	         
	         String csvFile = Filepath + "\\Emails.txt";
	 		BufferedReader bufRdr = new BufferedReader(new FileReader(csvFile));
	 		String line = "";
	 		line = bufRdr.readLine();
	 		// System.out.println("Line"+line);
	 		// String recipient = "saiyaswanth.m@sonata-software.com";
	 		String[] recipientList = line.split(",");
	 		InternetAddress[] recipientAddress = new InternetAddress[recipientList.length];
	 		int counter = 0;
	 		for (String recipient1 : recipientList) {
	 			recipientAddress[counter] = new InternetAddress(recipient1.trim());
	 			counter++;
	 		}
	         
	         
	         // Set To Field: adding recipient's email to from field. 
	         messag.setRecipients(Message.RecipientType.TO,recipientAddress); 
	  
	         // Set Subject: subject of the email 
	         messag.setSubject(subject); 
	  
	         // set body of the email. 
	         messag.setText(message); 
	  
	         // Send email. 
	         Transport.send(messag); 
	         System.out.println("Mail successfully sent"); 
	      } 
	      catch (MessagingException mex)  
	      { 
	         mex.printStackTrace(); 
	      } 
	}
}
