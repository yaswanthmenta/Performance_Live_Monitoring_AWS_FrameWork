package Live_Test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.Vector;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;

public class CopyFileNames_Without_Input {

	public static void main(String[] args) throws IOException {

		}
	
	public static void FilecopyStandAlone(String Filepath,String date,String time) throws IOException
	{			
		File file1 = new File(Filepath + "\\Filenames");
		String[] myFiles;
		if (file1.isDirectory()) {
			myFiles = file1.list();
			for (int i = 0; i < myFiles.length; i++) {
				File myFile = new File(file1, myFiles[i]);
				myFile.delete();
			}
		}
		int row = 0;
		int col = 0;
		String[][] arrayValues = new String[100][100];
		int filenumber = 0;
		String csvFile = Filepath + "\\Filenames_Standalone.csv";
		File f1 = new File(csvFile);
		if (f1.exists()) {

			BufferedReader bufRdr = new BufferedReader(new FileReader(csvFile));
			String line = "";
		
			while ((line = bufRdr.readLine()) != null) {
				StringTokenizer st = new StringTokenizer(line, ",");
				while (st.hasMoreTokens()) {
					arrayValues[row][col] = st.nextToken();
					col++;
				}
				row++;
				col = 0;
			}
			bufRdr.close();
		}

		String Filltime=time;
		time=Filltime.substring(0,2);
		int minutes = Integer.parseInt(Filltime.substring(2, 4));
		int minutes1 = minutes / 10;
		int minutes2 = minutes1 + 1;

			int SFTPPORT = 22;
	
			Session session = null;
			Channel channel = null;
			ChannelSftp channelSftp = null;

			try {
				JSch jsch = new JSch();
				for (int j = 0; j < row; j++) {
					String SFTPWORKINGDIR = arrayValues[j][0];
					String SFTPHOST = arrayValues[j][1];
					String SFTPUSER = arrayValues[j][2];
				String SFTPPASS = "No Password";
				String application = arrayValues[j][4];
					// System.out.println("hostname"+hostname);
			if (SFTPUSER == null) {
						break;
				}
					session = jsch.getSession(SFTPUSER, SFTPHOST, SFTPPORT);
				jsch.addIdentity(Filepath+"\\Services.ppk");
				java.util.Properties config = new java.util.Properties();
				config.put("StrictHostKeyChecking", "no");
				session.setConfig(config);
				session.connect();
				
				channel = session.openChannel("sftp");
				channel.connect();
				channelSftp = (ChannelSftp) channel;
				String dir=SFTPWORKINGDIR;
				SftpATTRS attrs=null;
				try {
				    attrs = channelSftp.stat(dir);
				} catch (Exception e) {
				}
				if (attrs != null) {
				channelSftp.cd(SFTPWORKINGDIR);
				Vector filelist = channelSftp.ls(SFTPWORKINGDIR);
				String[] listoffiles = new String[filelist.size()];
				for (int i = 0; i < filelist.size(); i++) {
					LsEntry entry = (LsEntry) filelist.get(i);
					listoffiles[i] = entry.getFilename();
				}
				ArrayList<String> listoffiles2 = new ArrayList<String>();
				for (int j1 = 0; j1 < listoffiles.length; j1++) {

					if (listoffiles[j1].contains("data-load-test")) {
						listoffiles2.add(listoffiles[j1].replace(
								"data-load-test-", ""));
					}
				}
				if (listoffiles2.contains(date)) {

					List<Integer> newList = new ArrayList<Integer>(
							listoffiles2.size());
					for (String myInt : listoffiles2) {
						newList.add(Integer.valueOf(myInt));
					}
					Collections.sort(newList);
					Collections.reverse(newList);
					SFTPWORKINGDIR = SFTPWORKINGDIR + "/"
							+ "data-load-test-" + date;
					channelSftp.cd(SFTPWORKINGDIR);
					Vector filelist1 = channelSftp.ls(SFTPWORKINGDIR);
					String[] listinside = new String[filelist1.size()];
					for (int i = 0; i < filelist1.size(); i++) {
						LsEntry entry = (LsEntry) filelist1.get(i);

						listinside[i] = entry.getFilename();
					}
					ArrayList<String> listoffiles3 = new ArrayList<String>();

					for (int j2 = 0; j2 < listinside.length; j2++) {
						if (listinside[j2].contains(".jtl")
								&& (listinside[j2].contains("eport_"
										+ date + "-" + time + minutes1))
								|| listinside[j2].contains(".csv")
								&& (listinside[j2].contains("errors_"
										+ date + "-" + time + minutes1))) {
							System.out.println("list of files::"+listinside[j2]);
							listoffiles3.add(listinside[j2]);
						}

						if (listinside[j2].contains(".jtl")
								&& (listinside[j2].contains("eport_"
										+ date + "-" + time + minutes2))
								|| listinside[j2].contains(".csv")
								&& (listinside[j2].contains("errors_"
										+ date + "-" + time + minutes2))) {
							System.out.println("list of files::"+listinside[j2]);
							listoffiles3.add(listinside[j2]);
						}

					}

					if (minutes >= 50 && minutes <= 60) {
						for (int j2 = 0; j2 < listinside.length; j2++) {
							int temptime = Integer.parseInt(time);
							int temptime1 = temptime + 1;
							String temptime2 = Integer
									.toString(temptime1);
							if (temptime1 <= 9) {
								temptime2 = "0" + temptime2;
							}
							if (listinside[j2].contains(".jtl")
									&& (listinside[j2]
											.contains("eport_" + date
													+ "-" + temptime2
													+ "0"))
									|| listinside[j2].contains(".csv")
									&& (listinside[j2]
											.contains("errors_" + date
													+ "-" + temptime2
													+ "0"))) {
								listoffiles3.add(listinside[j2]);
							}

						}
					}
					if (minutes > 60) {
						System.out.println("Please enter valid Time");
						break;
					}
					if (listoffiles3.size() != 0) {
						System.out
								.println(application
										+ " Results Exists for the Given Dates and Copying File Names");
						BufferedWriter output = null;

						File file = new File(Filepath
								+ "\\Filenames\\Test" + filenumber
								+ ".csv");
						filenumber = filenumber + 1;
						output = new BufferedWriter(
								new FileWriter(file));
						for(int a=0;a<listoffiles3.size();a++){
							output.write(SFTPWORKINGDIR + "/"
									+ listoffiles3.get(a) + ","
									+ SFTPWORKINGDIR + "/"
									+ listoffiles3.get(a+1) + "," + SFTPHOST
									+ "," + SFTPUSER + "," + SFTPPASS + ","
									+ application);
							output.newLine();
							a++;
						}
				
						output.close();
					}

					else {
						System.out
								.println("**********For "
										+ application
										+ " application there is no results file for the TIME specified********");
					}
				} else {
					System.out
							.println("**********For "
									+ application
									+ " application there is no results file for the DATE specified********");
					
				}
				
				channelSftp.exit();
				session.disconnect();
				}
				else {
				    System.out.println("********Directory Not Exists for "+application+"********");
				    //channelSftp.mkdir(dir);
				    channelSftp.exit();
					session.disconnect();
				}
			}
				 channelSftp.exit();
					session.disconnect();
				
			 }
				

			catch (Exception ex) {
				ex.printStackTrace();
			}
	}	
	
	
	
	
	public static void FilecopySpotMachine(String Filepath,String date,String time,String hostname) throws IOException
	{			
		
		String[][] arrayValues = new String[100][100];
		int filenumber = 0;
		String csvFile = Filepath + "\\FileNames.csv";
		File f1 = new File(csvFile);
		if (f1.exists()) {

			BufferedReader bufRdr = new BufferedReader(new FileReader(csvFile));
			String line = "";
			int row = 0;
			int col = 0;
			while ((line = bufRdr.readLine()) != null) {
				StringTokenizer st = new StringTokenizer(line, ",");
				while (st.hasMoreTokens()) {
					arrayValues[row][col] = st.nextToken();
					col++;
				}
				row++;
				col = 0;
			}
			bufRdr.close();
	 
	System.out.println("Please enter Test Date in YYYYMMDD Format");

	String Filltime=time;
	time=Filltime.substring(0,2);
	int minutes = Integer.parseInt(Filltime.substring(2, 4));
	
String SFTPHOST = hostname;
	int minutes1 = minutes / 10;
	int minutes2 = minutes1 + 1;

		int SFTPPORT = 22;
	
		Session session = null;
		Channel channel = null;
		ChannelSftp channelSftp = null;

		try {
			JSch jsch = new JSch();
		
				String SFTPUSER = "ec2-user";
				String SFTPPASS = "No Password";

			session = jsch.getSession(SFTPUSER, SFTPHOST, SFTPPORT);
			jsch.addIdentity(Filepath+"\\Services.ppk");
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			session.setConfig(config);
			session.connect();
			
			channel = session.openChannel("sftp");
			channel.connect();
			channelSftp = (ChannelSftp) channel;
			
			for (int l = 0; l < row; l++) {
				String SFTPWORKINGDIR = arrayValues[l][0];
				String application = arrayValues[l][4];
				if (application == null) {
					break;
				}
				
				String dir=SFTPWORKINGDIR;
				SftpATTRS attrs=null;
				try {
				    attrs = channelSftp.stat(dir);
				} catch (Exception e) {
				}
				if (attrs != null) {
				
				
			channelSftp.cd(SFTPWORKINGDIR);
			Vector filelist = channelSftp.ls(SFTPWORKINGDIR);
			String[] listoffiles = new String[filelist.size()];
			for (int i = 0; i < filelist.size(); i++) {
				LsEntry entry = (LsEntry) filelist.get(i);
				listoffiles[i] = entry.getFilename();

			}
			ArrayList<String> listoffiles2 = new ArrayList<String>();
			for (int j1 = 0; j1 < listoffiles.length; j1++) {

				if (listoffiles[j1].contains("data-load-test")) {
					listoffiles2.add(listoffiles[j1].replace(
							"data-load-test-", ""));
				}
			}

			if (listoffiles2.contains(date)) {

				List<Integer> newList = new ArrayList<Integer>(
						listoffiles2.size());
				for (String myInt : listoffiles2) {
					newList.add(Integer.valueOf(myInt));
				}
				Collections.sort(newList);
				Collections.reverse(newList);
				SFTPWORKINGDIR = SFTPWORKINGDIR + "/"
						+ "data-load-test-" + date;
				channelSftp.cd(SFTPWORKINGDIR);
				Vector filelist1 = channelSftp.ls(SFTPWORKINGDIR);
				String[] listinside = new String[filelist1.size()];
				for (int i = 0; i < filelist1.size(); i++) {
					LsEntry entry = (LsEntry) filelist1.get(i);

					listinside[i] = entry.getFilename();
				}
				ArrayList<String> listoffiles3 = new ArrayList<String>();

				for (int j2 = 0; j2 < listinside.length; j2++) {
					if (listinside[j2].contains(".jtl")
							&& (listinside[j2].contains("eport_"
									+ date + "-" + time + minutes1))
							|| listinside[j2].contains(".csv")
							&& (listinside[j2].contains("errors_"
									+ date + "-" + time + minutes1))) {
						System.out.println("list of files::"+listinside[j2]);
						listoffiles3.add(listinside[j2]);
					}

					if (listinside[j2].contains(".jtl")
							&& (listinside[j2].contains("eport_"
									+ date + "-" + time + minutes2))
							|| listinside[j2].contains(".csv")
							&& (listinside[j2].contains("errors_"
									+ date + "-" + time + minutes2))) {
						System.out.println("list of files::"+listinside[j2]);
						listoffiles3.add(listinside[j2]);
					}

				}

				if (minutes >= 50 && minutes <= 60) {
					for (int j2 = 0; j2 < listinside.length; j2++) {
						int temptime = Integer.parseInt(time);
						int temptime1 = temptime + 1;
						String temptime2 = Integer
								.toString(temptime1);
						if (temptime1 <= 9) {
							temptime2 = "0" + temptime2;
						}
						if (listinside[j2].contains(".jtl")
								&& (listinside[j2]
										.contains("eport_" + date
												+ "-" + temptime2
												+ "0"))
								|| listinside[j2].contains(".csv")
								&& (listinside[j2]
										.contains("errors_" + date
												+ "-" + temptime2
												+ "0"))) {
							listoffiles3.add(listinside[j2]);
						}

					}
				}
				if (minutes > 60) {
					System.out.println("Please enter valid Time");
					break;
				}
				if (listoffiles3.size() != 0) {
					System.out
							.println(application
									+ " Results Exists for the Given Dates and Copying File Names");
					BufferedWriter output = null;

					File file = new File(Filepath
							+ "\\Filenames\\Test" + filenumber
							+ ".csv");
					filenumber = filenumber + 1;
					output = new BufferedWriter(
							new FileWriter(file));

					for(int a=0;a<listoffiles3.size();a++){
						output.write(SFTPWORKINGDIR + "/"
								+ listoffiles3.get(a) + ","
								+ SFTPWORKINGDIR + "/"
								+ listoffiles3.get(a+1) + "," + SFTPHOST
								+ "," + SFTPUSER + "," + SFTPPASS + ","
								+ application);
						output.newLine();
						a++;
					}
		
					output.close();
				}

				else {
					System.out
							.println("**********For "
									+ application
									+ " application there is no results file for the TIME specified********");
				}
			} else {
				System.out
						.println("**********For "
								+ application
								+ " application there is no results file for the DATE specified********");
				
			}
				}
				else {
				    System.out.println("********Directory Not Exists for "+application+"********");
				    //channelSftp.mkdir(dir);
				//    channelSftp.exit();
					session.disconnect();
				}
		}
				
			channelSftp.exit();
			session.disconnect();
			System.out.println("Session Disconnected...!!!");
			
		}
			
			
		catch (Exception ex) {
			ex.printStackTrace();
		}
		 channelSftp.exit();
			session.disconnect();
		}
		
		
else {
	System.out.println("Please enter a valid option..");
}
	}
}
