package ResponseTimeComp;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;

public class ReadingAggregates_ResponseTimeComp {
public static void main(String args[]) throws IOException {
	String Filepath=args[0];
	List<String> results = new ArrayList<String>();
	List<String> SameFileNames = new ArrayList<String>();
	String NewFilepath=Filepath+"\\ReportAutomation\\Reports\\PerformanceReport-20161103\\";
	File[] files = new File(NewFilepath).listFiles();
	//If this pathname does not denote a directory, then listFiles() returns null. 

	for (File file : files) {
	    if (file.isFile()) {
	    	if(file.getName().contains(".csv")) {
	        results.add(file.getName());
	    	}
	    }
	}
	String AllNamesCombined="";
	BufferedWriter output = null;
	File file = new File(Filepath+"\\ResponseTimeComp\\Results\\ResponseTimeCompReport_"+getCurrentDate()+".html");
	output = new BufferedWriter(new FileWriter(file));
	output.write("<html><head></head><body>");
	String[][] arrayValues = new String[700][20];
	String[][] arrayValues1 = new String[700][20];
	for(int a=0;a<results.size();a++) {
		int count=0;
		for(int b=a+1; b<results.size();b++) {
			if(results.get(a).substring(0, 20).equals(results.get(b).substring(0, 20))) {
			System.out.println(results.get(a)+"__"+results.get(b));	
			AllNamesCombined=AllNamesCombined+"_"+results.get(a)+"__"+results.get(b);
			String csvFile1 = NewFilepath+"\\"+results.get(a);
			String csvFile2 = NewFilepath+"\\"+results.get(b);;
			String[] recipientList1 = results.get(a).replace(".csv", "").split("_");
			String[] recipientList2 = results.get(b).replace(".csv", "").split("_");
			// System.out.println("Please enter the Executable file");
			File f1 = new File(csvFile1);
			//if (f1.exists()) {

				BufferedReader bufRdr = new BufferedReader(new FileReader(csvFile1));
				String line = "";
				int row = 0;
				int col = 0;

				// read each line of text file
				while ((line = bufRdr.readLine()) != null) {
					StringTokenizer st = new StringTokenizer(line, ",");
					col = 0;
					while (st.hasMoreTokens()) {
						// get next token and store it in the array
						arrayValues[row][col] = st.nextToken();
						col++;
					}
					//col = 0;
					row++;
					//
				}
				
				
				File f2 = new File(csvFile2);
				//if (f1.exists()) {

					BufferedReader bufRdr1 = new BufferedReader(new FileReader(csvFile2));
					String line1 = "";
					int row1 = 0;
					int col1 = 0;

					// read each line of text file
					while ((line1 = bufRdr1.readLine()) != null) {
						StringTokenizer st = new StringTokenizer(line1, ",");
						col1 = 0;
						while (st.hasMoreTokens()) {
							// get next token and store it in the array
							arrayValues1[row1][col1] = st.nextToken();
							col1++;
						}
						//col = 0;
						row1++;
						//
					}
				// close the file
				bufRdr.close();
			//	int count=0;
				ArrayList<String> listoffiles = new ArrayList<String>();
			//	System.out.println(arrayValues[1][0]+","+arrayValues[1][4]+","+arrayValues1[1][4]);
			//	BufferedWriter output = null;
				//File file = new File("D:\\Performance\\Reports\\ResponseTimeComp\\Result.html");
				//output = new BufferedWriter(new FileWriter(file));
				//System.out.println("Row"+row+row1);
				//System.out.println("colum"+col+col1);
				
				
			
			
				
				output.write("<h2><center><b>"+recipientList1[0]+" Comparison Report for "+recipientList1[2]+" VS "+recipientList2[2]+"</b></center></h2>"
		+"<div class=\"panel\">"
		+"<p>");
					output.write("<center><table border=\"3\" width=\"1000\">");
				output.write("<tr><th width=\"600\">Name Of The Request</th><th width=\"100\">"+recipientList1[2]+"</th><th width=\"100\">"+recipientList2[2]+"</th><th width=\"100\">"+recipientList1[2]+" VS "+recipientList2[2]+"</th></tr>");
				
				for(int i=0;i<row;i++){
				for(int j=0;j<row1;j++){
				//	System.out.println(arrayValues[i][0]+","+arrayValues[j][0]);
				if((arrayValues[i][0].equals(arrayValues1[j][0]))&&(!arrayValues[i][1].equals("aggregate_report_90%_line"))){
				//	System.out.println("In for loop"+i+j);
				//	count++;
					if(!arrayValues[i][0].equals("TOTAL") && !arrayValues[i][0].equals("sampler_label")){
					output.write("<tr><td>" + arrayValues[i][0] + "</td><td>" + arrayValues[i][4] + "</td><td>" + arrayValues1[j][4] + "</td><td align=\"center\" bgcolor="+colour(arrayValues[i][4],arrayValues1[j][4],"decide")+"><p style=\"color:black;\"><b>" + Result(arrayValues[i][4],arrayValues1[j][4])+"%" + "</b></p></td></tr>");
					//output.write(arrayValues[i][0]+","+arrayValues[i][4]+","+arrayValues1[j][4]);
					//output.newLine();
					listoffiles.add(arrayValues1[j][0]);
					listoffiles.add(arrayValues[i][0]);
					}
				}
				listoffiles.add("TOTAL");
				listoffiles.add("sampler_label");
				//System.out.println("Count"+count);
				//count=0;
				}
				}
				for(int i=0;i<row;i++){
					//	System.out.println(arrayValues[i][0]+","+arrayValues[j][0]);
					if(!listoffiles.contains(arrayValues[i][0])){
						//output.write(arrayValues[i][0]+","+arrayValues[i][4]+",0");
						output.write("<tr><td>" + arrayValues[i][0] + "</td><td>" + arrayValues[i][4] + "</td><td >" +"0"+ "</td><td align=\"center\" bgcolor="+colour(arrayValues[i][4],"0","decide")+"><b>"+ Result(arrayValues[i][4],"0")+"%" + "</b></td></tr>");
						//output.newLine();
					}
				}
					for(int j=0;j<row1;j++){
						//	System.out.println(arrayValues[i][0]+","+arrayValues[j][0]);
						if(!listoffiles.contains(arrayValues1[j][0])){
						//	output.write(arrayValues1[j][0]+",0,"+arrayValues1[j][4]);
							output.write("<tr><td>" + arrayValues1[j][0] + "</td><td>" + "0" + "</td><td >" +arrayValues1[j][4]+ "</td><td align=\"center\" bgcolor="+colour("0",arrayValues1[j][4],"decide")+" ><b>"+ Result("0",arrayValues1[j][4])+"%" + "</b></td></tr>");	
						//	output.newLine();
						}
					
					}
					output.write("</table></center></p><br/><br/></div>");
					output.write("<p></p>");
				//	System.out.println("Comparision done for "+filenumber[i1]);
			
			
			count++;
			}
			
		}
		if(count==0 && !AllNamesCombined.contains(results.get(a))) {
			output.write("<center><table border=\"3\" width=\"1000\"><tr><td><h3>Only One Test Data Is Available, Comparision Is Not Possible For "+results.get(a)+"</h3></tr></td></table><center>");
			System.out.println("Only Single File not able to compare::"+results.get(a));	
		}
}
	output.write("</body></html>");
	System.out.println("Done..!!");
		output.close();
/*	File file1 = new File(NewFilepath+results.get(a));
	FileReader fr1 = new FileReader(file1);
	BufferedReader br1 = new BufferedReader(fr1);


	  String st1=""; 
	  while ((st1 = br1.readLine()) != null){
		  TransactionsToBeChecked.add(st1);
	  }
	  br1.close();
	  fr1.close();
	  */
}



private static String colour(String Test1, String Test2, String colour) {
	String	finalresult="";
	String undefined="Red";
	if((Test1.equals("aggregate_report_90%_line"))||(Test2.equals("aggregate_report_90%_line")))
	{
		return undefined;
	}
	
	else if(!Test1.equals("0")){
	Double str1 =Double.parseDouble(Test1) ;
	Double str2 =Double.parseDouble(Test2) ;

	Double	result=(str1-str2)/str1;
result=result*100;
int a = (int) Math.round(result);
finalresult=Double.toString(a);
if(a>=0){
finalresult="Green";
}
if(a<0){
finalresult="Red";
}
if(a==0){
finalresult="White";
}
return finalresult;
}
	return undefined;
	
}

public static String Result(String Test1,String Test2)
{
	String undefined="NA";
	if((Test1.equals("aggregate_report_90%_line"))||(Test2.equals("aggregate_report_90%_line")))
	{
		return undefined;
	}
	
	else if(!Test1.equals("0")){
	Double str1 =Double.parseDouble(Test1) ;
	Double str2 =Double.parseDouble(Test2) ;

	Double	result=(str1-str2)/str1;
result=result*100;
int a = (int) Math.round(result);
String	finalresult=Double.toString(a);

	return finalresult;
	}
	else
		return undefined;
	
}

public static String getCurrentDate()
{
 String str = "";
 try
     {
       Date localDate = new Date();
       SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyyMMdd-hhmmss");
       str = localSimpleDateFormat.format(localDate);
     }
    catch (Exception localException)
     {
       System.out.println("Execption in while returning the current date:" + localException);
     }
     return str;
  }

}
