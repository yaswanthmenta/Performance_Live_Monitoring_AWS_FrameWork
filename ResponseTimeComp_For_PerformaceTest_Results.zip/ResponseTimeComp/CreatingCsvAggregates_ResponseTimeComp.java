package ResponseTimeComp;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CreatingCsvAggregates_ResponseTimeComp {
public static void main(String[] args) throws IOException, InterruptedException {
	String Filepath=args[0];
	List<String> results = new ArrayList<String>();
	String NewFilepath=Filepath+"\\ReportAutomation\\Reports\\PerformanceReport-20161103\\";
	File[] files = new File(NewFilepath).listFiles();
	//If this pathname does not denote a directory, then listFiles() returns null. 

	for (File file : files) {
	    if (file.isFile()) {
	        results.add(file.getName());
	    }
	}
	BufferedWriter output = null;
	File file = new File(Filepath+"\\ResponseTimeComp\\AggregateAuto.bat");
	output = new BufferedWriter(new FileWriter(file));
	output.write("set projectpath="+Filepath+"\\CompleteAuto\\apache-jmeter-2.9\\lib");
	output.newLine();
	output.write("cd %projectpath%");
	output.newLine();
	
	for(int a=0;a<results.size();a++) {
		String AggregateName=results.get(a).replace(".jtl", ".csv");
		output.write("java -jar cmdrunner-2.0.jar --tool Reporter --generate-csv  "+NewFilepath+"\\"+AggregateName+" --input-jtl "+NewFilepath+"\\"+results.get(a)+" --plugin-type AggregateReport");
		output.newLine();
	}
	
	//output.close();
	
	output.write("set projectpath="+Filepath+"\\ResponseTimeComp_Bat_Details");
	output.newLine();
	output.write("cd %projectpath%");
	output.newLine();
	output.write("java -jar ReadingAggregates_ResponseTimeComp.jar "+Filepath);
	output.newLine();
	output.write("pause");
	output.close();
	
	Process p=null;
	try {
        p =  Runtime.getRuntime().exec("cmd /c start "+Filepath+"\\ResponseTimeComp\\AggregateAuto.bat\"") ;           
        Thread.sleep(10000);
        //	p.destroy();
       
	} catch (IOException ex) {
    }
	finally {
		p.destroy();
	}
	
}
}
