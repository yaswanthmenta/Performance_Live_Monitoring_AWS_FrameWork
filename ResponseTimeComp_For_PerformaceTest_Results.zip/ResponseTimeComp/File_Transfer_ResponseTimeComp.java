package ResponseTimeComp;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.Vector;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
//import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

public class File_Transfer_ResponseTimeComp {

	public static void main(String[] args) throws IOException {

		// Scanner sc=new Scanner(System.in);
		// String Filepath=sc.next();
		String Filepath = args[0];
		File file1 = new File(Filepath + "\\Filenames");
		String[] myFiles;
		if (file1.isDirectory()) {
			myFiles = file1.list();
			for (int i = 0; i < myFiles.length; i++) {
				File myFile = new File(file1, myFiles[i]);
				myFile.delete();
			}
		}



			Scanner s = new Scanner(System.in);
			System.out.println("Please select any one:   ");
			System.out
					.println("1.ResponseTimeComparision for All Brands with Specific Date and Time using Standalone Ec2 Machines");
			System.out
					.println("2.ResponseTimeComparision for All Brands with Specific Date and Time using Spot Ec2 Instances");
		//	System.out
			//		.println("3.LIVE TEST MONITORING for All Brands with Specific Date and Time using Standalone Ec2 Machines");
			//System.out
			//		.println("4.LIVE TEST MONITORING for All Brands with Specific Date and Time using Spot Ec2 Instances");
			String option = s.next();
		//	s.close();
			List<String> TesstartDate = new ArrayList<String>();
			List<String> TesstartHour = new ArrayList<String>();
			List<Integer> TesstartMinute = new ArrayList<Integer>();
			
			//System.out.println("Please Select Comparision for number of Tests:   ");
			if (option.equals("1")) { // <<<<<-------------------OPTION1---------------------------->>>>>
				Scanner s1 = new Scanner(System.in);
				System.out.println("Please Select Comparision for number of Tests:   ");
				int testcompcount=s.nextInt();	
				for(int e=1; e<=testcompcount;e++) {
				
				System.out.println("Please enter "+e+" Test Date in YYYYMMDD Format");
				String date = s1.next();
				TesstartDate.add(date);
				System.out.println("Please enter "+e+" Test start hour in HH format");
				String time = s1.next();
				TesstartHour.add(time);
				System.out
						.println("Please enter "+e+" Test start minutes in MM format");
				int minutes = s1.nextInt();
				TesstartMinute.add(minutes);
				}	
s1.close();
				
					// close the file
int filenumber = 0;		
			for(int k=0;k<TesstartDate.size();k++) {	
				int row = 0;
				int col = 0;
				String[][] arrayValues = new String[100][100];
				
				String csvFile = Filepath + "\\Filenames_Standalone.csv";
				// System.out.println("Please enter the Executable file");
				File f1 = new File(csvFile);
				if (f1.exists()) {

					BufferedReader bufRdr = new BufferedReader(new FileReader(csvFile));
					String line = "";
				
					// read each line of text file
					while ((line = bufRdr.readLine()) != null) {
						StringTokenizer st = new StringTokenizer(line, ",");
						while (st.hasMoreTokens()) {
							// get next token and store it in the array
							arrayValues[row][col] = st.nextToken();
							col++;
						}
						row++;
						col = 0;
					}
					bufRdr.close();
				}
			//	System.out.println("Please enter Test Date in YYYYMMDD Format");
				String date =TesstartDate.get(k);
				String time = TesstartHour.get(k);
				int minutes = TesstartMinute.get(k);
			//	System.out
				//.println("Please enter Spot Instance IP Address::");
		//String SFTPHOST = s1.next();
				//s1.close();
				int minutes1 = minutes / 10;
				int minutes2 = minutes1 + 1;
				// System.out.println("minutes"+minutes1+minutes2);
				/*
				 * for (int k = 0; k < row; k++) { String application =
				 * arrayValues[k][4]; //
				 * System.out.println("hostname"+hostname); if (application ==
				 * null) { break; } System.out.println("Please press " + k +
				 * " for " + application); }
				 * System.out.println("Please press all for All the Applications"
				 * ); Scanner s = new Scanner(System.in); String AppNum =
				 * s.next();
				 * 
				 * if (!AppNum.equals("all")) {
				 * 
				 * int AppNum1 = Integer.parseInt(AppNum); String SFTPWORKINGDIR
				 * = arrayValues[AppNum1][0]; String SFTPHOST =
				 * arrayValues[AppNum1][1]; String SFTPUSER =
				 * arrayValues[AppNum1][2]; String SFTPPASS =
				 * arrayValues[AppNum1][3]; String application =
				 * arrayValues[AppNum1][4];
				 */
		/*		for (int j = 0; j < row; j++) {
					String SFTPWORKINGDIR = arrayValues[j][0];
					String SFTPHOST = arrayValues[j][1];
					String SFTPUSER = arrayValues[j][2];
				String SFTPPASS = "No Password";
				String application = arrayValues[j][4];
					// System.out.println("hostname"+hostname);
			if (SFTPUSER == null) {
						break;
				}*/

					int SFTPPORT = 22;
					// String SFTPWORKINGDIR =
					// "/tui/jmeter/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT";

					Session session = null;
					Channel channel = null;
					ChannelSftp channelSftp = null;

					try {
						JSch jsch = new JSch();
						for (int j = 0; j < row; j++) {
							String SFTPWORKINGDIR = arrayValues[j][0];
							String SFTPHOST = arrayValues[j][1];
							String SFTPUSER = arrayValues[j][2];
						String SFTPPASS = "No Password";
						String application = arrayValues[j][4];
							// System.out.println("hostname"+hostname);
					if (SFTPUSER == null) {
								break;
						}
					//	for (int l = 0; l < row; l++) {
					//		String SFTPWORKINGDIR = arrayValues[l][0];
						//	String SFTPHOST = arrayValues[j][1];
						//	String SFTPUSER = "ec2-user";
					//		String SFTPPASS = "No Password";
					//		String application = arrayValues[l][4];
							// System.out.println("hostname"+hostname);
						//	if (SFTPUSER == null) {
					//			break;
					//		}
						session = jsch.getSession(SFTPUSER, SFTPHOST, SFTPPORT);
					//	session.setPassword(SFTPPASS);
						jsch.addIdentity(Filepath+"\\Services.ppk");
						java.util.Properties config = new java.util.Properties();
						config.put("StrictHostKeyChecking", "no");
						session.setConfig(config);
						session.connect();
						
						channel = session.openChannel("sftp");
						channel.connect();
						channelSftp = (ChannelSftp) channel;
						
					//	for (int l = 0; l < row; l++) {
				//			String SFTPWORKINGDIR = arrayValues[l][0];
						//	String SFTPHOST = arrayValues[j][1];
						//	 SFTPUSER = arrayValues[l][2];
						//	String SFTPPASS = "No Password";
					//		String application = arrayValues[l][4];
							// System.out.println("hostname"+hostname);
						//	if (application == null) {
						//		break;
						//	}
						channelSftp.cd(SFTPWORKINGDIR);
					//	channelSftp.
						Vector filelist = channelSftp.ls(SFTPWORKINGDIR);
						String[] listoffiles = new String[filelist.size()];
						for (int i = 0; i < filelist.size(); i++) {
							LsEntry entry = (LsEntry) filelist.get(i);
							// System.out.println(entry.getFilename());
							listoffiles[i] = entry.getFilename();

						}
						ArrayList<String> listoffiles2 = new ArrayList<String>();
						for (int j1 = 0; j1 < listoffiles.length; j1++) {

							if (listoffiles[j1].contains("data-load-test")) {
								listoffiles2.add(listoffiles[j1].replace(
										"data-load-test-", ""));
							}
						}

						if (listoffiles2.contains(date)) {

							List<Integer> newList = new ArrayList<Integer>(
									listoffiles2.size());
							for (String myInt : listoffiles2) {
								newList.add(Integer.valueOf(myInt));
							}
							// System.out.println(newList);
							Collections.sort(newList);
							Collections.reverse(newList);
							// System.out.println(newList);
							SFTPWORKINGDIR = SFTPWORKINGDIR + "/"
									+ "data-load-test-" + date;
							channelSftp.cd(SFTPWORKINGDIR);
							Vector filelist1 = channelSftp.ls(SFTPWORKINGDIR);
							String[] listinside = new String[filelist1.size()];
							for (int i = 0; i < filelist1.size(); i++) {
								LsEntry entry = (LsEntry) filelist1.get(i);

								listinside[i] = entry.getFilename();
					//			channelSftp.exit();
					//			session.disconnect();
							}
							ArrayList<String> listoffiles3 = new ArrayList<String>();

							for (int j2 = 0; j2 < listinside.length; j2++) {
//System.out.println("list of files::"+listinside[j2]);
								if (listinside[j2].contains(".jtl")
										&& (listinside[j2].contains("eport_"
												+ date + "-" + time + minutes1))) {
									System.out.println("list of files::"+listinside[j2]);
									listoffiles3.add(listinside[j2]);
								}

								if (listinside[j2].contains(".jtl")
										&& (listinside[j2].contains("eport_"
												+ date + "-" + time + minutes2))) {
									System.out.println("list of files::"+listinside[j2]);
									listoffiles3.add(listinside[j2]);
								}

							}

							if (minutes >= 50 && minutes <= 60) {
								for (int j2 = 0; j2 < listinside.length; j2++) {
									int temptime = Integer.parseInt(time);
									int temptime1 = temptime + 1;
									String temptime2 = Integer
											.toString(temptime1);
									if (temptime1 <= 9) {
										temptime2 = "0" + temptime2;
									}
									// System.out.println("temptime"+temptime2);
									if (listinside[j2].contains(".jtl")
											&& (listinside[j2]
													.contains("eport_" + date
															+ "-" + temptime2
															+ "0"))) {
										listoffiles3.add(listinside[j2]);
									}

								}
							}
							if (minutes > 60) {
								System.out.println("Please enter valid Time");
								break;
							}
							if (listoffiles3.size() != 0) {
								// System.out.println(listoffiles3+","+listoffiles3.size());
								System.out
										.println(application
												+ " Results Exists for the Given Dates and Copying File Names");
								BufferedWriter output = null;

								File file = new File(Filepath
										+ "\\Filenames\\Test" + filenumber
										+ ".csv");
								filenumber = filenumber + 1;
								output = new BufferedWriter(
										new FileWriter(file));
								// System.out.println("Application:"+application);

								for(int a=0;a<listoffiles3.size();a++){
									output.write(SFTPWORKINGDIR + "/"
											+ listoffiles3.get(a)
											+ "," + SFTPHOST
											+ "," + SFTPUSER + "," + SFTPPASS + ","
											+ application);
									output.newLine();
								//	a++;
								}
							/*	output.write(SFTPWORKINGDIR + "/"
										+ listoffiles3.get(0) + ","
										+ SFTPWORKINGDIR + "/"
										+ listoffiles3.get(1) + "," + SFTPHOST
										+ "," + SFTPUSER + "," + SFTPPASS + ","
										+ application);
								if (listoffiles3.size() == 4) {
									output.newLine();
									output.write(SFTPWORKINGDIR + "/"
											+ listoffiles3.get(2) + ","
											+ SFTPWORKINGDIR + "/"
											+ listoffiles3.get(3) + ","
											+ SFTPHOST + "," + SFTPUSER + ","
											+ SFTPPASS + "," + application);
								}*/
								output.close();
							}

							else {
								System.out
										.println("**********For "
												+ application
												+ " application there is no results file for the TIME specified********");
							}
						} else {
							System.out
									.println("**********For "
											+ application
											+ " application there is no results file for the DATE specified********");
							
						}
						
						channelSftp.exit();
						session.disconnect();
					//	System.out.println("Session Disconnected...!!!");
					}
						
					
						
					 }

					catch (Exception ex) {
						ex.printStackTrace();
					}
				}
			}
	
				
			 else if (option.equals("2")) {
					Scanner s1 = new Scanner(System.in);
					System.out.println("Please enter a Spot Instance IP:");
					String SFTPHOST = s1.next();
					System.out.println("Please Select Comparision for number of Tests:   ");
					int testcompcount=s.nextInt();	
					for(int e=1; e<=testcompcount;e++) {
					
					System.out.println("Please enter "+e+" Test Date in YYYYMMDD Format");
					String date = s1.next();
					TesstartDate.add(date);
					System.out.println("Please enter "+e+" Test start hour in HH format");
					String time = s1.next();
					TesstartHour.add(time);
					System.out
							.println("Please enter "+e+" Test start minutes in MM format");
					int minutes = s1.nextInt();
					TesstartMinute.add(minutes);
					}	
	s1.close();
					
						// close the file
	int filenumber = 0;	
				for(int k=0;k<TesstartDate.size();k++) {	
					int row = 0;
					int col = 0;
					String[][] arrayValues = new String[100][100];
					
					String csvFile = Filepath + "\\Filenames.csv";
					// System.out.println("Please enter the Executable file");
					File f1 = new File(csvFile);
					if (f1.exists()) {

						BufferedReader bufRdr = new BufferedReader(new FileReader(csvFile));
						String line = "";
					
						// read each line of text file
						while ((line = bufRdr.readLine()) != null) {
							StringTokenizer st = new StringTokenizer(line, ",");
							while (st.hasMoreTokens()) {
								// get next token and store it in the array
								arrayValues[row][col] = st.nextToken();
								col++;
							}
							row++;
							col = 0;
						}
						bufRdr.close();
					}
				//	System.out.println("Please enter Test Date in YYYYMMDD Format");
					String date =TesstartDate.get(k);
					String time = TesstartHour.get(k);
					int minutes = TesstartMinute.get(k);
				//	System.out
					//.println("Please enter Spot Instance IP Address::");
			//String SFTPHOST = s1.next();
					//s1.close();
					int minutes1 = minutes / 10;
					int minutes2 = minutes1 + 1;
					// System.out.println("minutes"+minutes1+minutes2);
					/*
					 * for (int k = 0; k < row; k++) { String application =
					 * arrayValues[k][4]; //
					 * System.out.println("hostname"+hostname); if (application ==
					 * null) { break; } System.out.println("Please press " + k +
					 * " for " + application); }
					 * System.out.println("Please press all for All the Applications"
					 * ); Scanner s = new Scanner(System.in); String AppNum =
					 * s.next();
					 * 
					 * if (!AppNum.equals("all")) {
					 * 
					 * int AppNum1 = Integer.parseInt(AppNum); String SFTPWORKINGDIR
					 * = arrayValues[AppNum1][0]; String SFTPHOST =
					 * arrayValues[AppNum1][1]; String SFTPUSER =
					 * arrayValues[AppNum1][2]; String SFTPPASS =
					 * arrayValues[AppNum1][3]; String application =
					 * arrayValues[AppNum1][4];
					 */
			/*		for (int j = 0; j < row; j++) {
						String SFTPWORKINGDIR = arrayValues[j][0];
						String SFTPHOST = arrayValues[j][1];
						String SFTPUSER = arrayValues[j][2];
					String SFTPPASS = "No Password";
					String application = arrayValues[j][4];
						// System.out.println("hostname"+hostname);
				if (SFTPUSER == null) {
							break;
					}*/

						int SFTPPORT = 22;
						// String SFTPWORKINGDIR =
						// "/tui/jmeter/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT";

						Session session = null;
						Channel channel = null;
						ChannelSftp channelSftp = null;

						try {
							JSch jsch = new JSch();
							for (int j = 0; j < row; j++) {
								String SFTPWORKINGDIR = arrayValues[j][0];
								
								String SFTPUSER = arrayValues[j][2];
							String SFTPPASS = "No Password";
							String application = arrayValues[j][4];
								// System.out.println("hostname"+hostname);
						if (SFTPUSER == null) {
									break;
							}
						//	for (int l = 0; l < row; l++) {
						//		String SFTPWORKINGDIR = arrayValues[l][0];
							//	String SFTPHOST = arrayValues[j][1];
							//	String SFTPUSER = "ec2-user";
						//		String SFTPPASS = "No Password";
						//		String application = arrayValues[l][4];
								// System.out.println("hostname"+hostname);
							//	if (SFTPUSER == null) {
						//			break;
						//		}
							session = jsch.getSession(SFTPUSER, SFTPHOST, SFTPPORT);
						//	session.setPassword(SFTPPASS);
							jsch.addIdentity(Filepath+"\\Services.ppk");
							java.util.Properties config = new java.util.Properties();
							config.put("StrictHostKeyChecking", "no");
							session.setConfig(config);
							session.connect();
							
							channel = session.openChannel("sftp");
							channel.connect();
							channelSftp = (ChannelSftp) channel;
							
						//	for (int l = 0; l < row; l++) {
					//			String SFTPWORKINGDIR = arrayValues[l][0];
							//	String SFTPHOST = arrayValues[j][1];
							//	 SFTPUSER = arrayValues[l][2];
							//	String SFTPPASS = "No Password";
						//		String application = arrayValues[l][4];
								// System.out.println("hostname"+hostname);
							//	if (application == null) {
							//		break;
							//	}
							channelSftp.cd(SFTPWORKINGDIR);
						//	channelSftp.
							Vector filelist = channelSftp.ls(SFTPWORKINGDIR);
							String[] listoffiles = new String[filelist.size()];
							for (int i = 0; i < filelist.size(); i++) {
								LsEntry entry = (LsEntry) filelist.get(i);
								// System.out.println(entry.getFilename());
								listoffiles[i] = entry.getFilename();

							}
							ArrayList<String> listoffiles2 = new ArrayList<String>();
							for (int j1 = 0; j1 < listoffiles.length; j1++) {

								if (listoffiles[j1].contains("data-load-test")) {
									listoffiles2.add(listoffiles[j1].replace(
											"data-load-test-", ""));
								}
							}

							if (listoffiles2.contains(date)) {

								List<Integer> newList = new ArrayList<Integer>(
										listoffiles2.size());
								for (String myInt : listoffiles2) {
									newList.add(Integer.valueOf(myInt));
								}
								// System.out.println(newList);
								Collections.sort(newList);
								Collections.reverse(newList);
								// System.out.println(newList);
								SFTPWORKINGDIR = SFTPWORKINGDIR + "/"
										+ "data-load-test-" + date;
								channelSftp.cd(SFTPWORKINGDIR);
								Vector filelist1 = channelSftp.ls(SFTPWORKINGDIR);
								String[] listinside = new String[filelist1.size()];
								for (int i = 0; i < filelist1.size(); i++) {
									LsEntry entry = (LsEntry) filelist1.get(i);

									listinside[i] = entry.getFilename();
						//			channelSftp.exit();
						//			session.disconnect();
								}
								ArrayList<String> listoffiles3 = new ArrayList<String>();

								for (int j2 = 0; j2 < listinside.length; j2++) {
	//System.out.println("list of files::"+listinside[j2]);
									if (listinside[j2].contains(".jtl")
											&& (listinside[j2].contains("eport_"
													+ date + "-" + time + minutes1))) {
										System.out.println("list of files::"+listinside[j2]);
										listoffiles3.add(listinside[j2]);
									}

									if (listinside[j2].contains(".jtl")
											&& (listinside[j2].contains("eport_"
													+ date + "-" + time + minutes2))) {
										System.out.println("list of files::"+listinside[j2]);
										listoffiles3.add(listinside[j2]);
									}

								}

								if (minutes >= 50 && minutes <= 60) {
									for (int j2 = 0; j2 < listinside.length; j2++) {
										int temptime = Integer.parseInt(time);
										int temptime1 = temptime + 1;
										String temptime2 = Integer
												.toString(temptime1);
										if (temptime1 <= 9) {
											temptime2 = "0" + temptime2;
										}
										// System.out.println("temptime"+temptime2);
										if (listinside[j2].contains(".jtl")
												&& (listinside[j2]
														.contains("eport_" + date
																+ "-" + temptime2
																+ "0"))) {
											listoffiles3.add(listinside[j2]);
										}

									}
								}
								if (minutes > 60) {
									System.out.println("Please enter valid Time");
									break;
								}
								if (listoffiles3.size() != 0) {
									// System.out.println(listoffiles3+","+listoffiles3.size());
									System.out
											.println(application
													+ " Results Exists for the Given Dates and Copying File Names");
									BufferedWriter output = null;

									File file = new File(Filepath
											+ "\\Filenames\\Test" + filenumber
											+ ".csv");
									filenumber = filenumber + 1;
									output = new BufferedWriter(
											new FileWriter(file));
									// System.out.println("Application:"+application);

									for(int a=0;a<listoffiles3.size();a++){
										output.write(SFTPWORKINGDIR + "/"
												+ listoffiles3.get(a)
												+ "," + SFTPHOST
												+ "," + SFTPUSER + "," + SFTPPASS + ","
												+ application);
										output.newLine();
									//	a++;
									}
								/*	output.write(SFTPWORKINGDIR + "/"
											+ listoffiles3.get(0) + ","
											+ SFTPWORKINGDIR + "/"
											+ listoffiles3.get(1) + "," + SFTPHOST
											+ "," + SFTPUSER + "," + SFTPPASS + ","
											+ application);
									if (listoffiles3.size() == 4) {
										output.newLine();
										output.write(SFTPWORKINGDIR + "/"
												+ listoffiles3.get(2) + ","
												+ SFTPWORKINGDIR + "/"
												+ listoffiles3.get(3) + ","
												+ SFTPHOST + "," + SFTPUSER + ","
												+ SFTPPASS + "," + application);
									}*/
									output.close();
								}

								else {
									System.out
											.println("**********For "
													+ application
													+ " application there is no results file for the TIME specified********");
								}
							} else {
								System.out
										.println("**********For "
												+ application
												+ " application there is no results file for the DATE specified********");
								
							}
							
							channelSftp.exit();
							session.disconnect();
						//	System.out.println("Session Disconnected...!!!");
						}
							
						
							
						 }

						catch (Exception ex) {
							ex.printStackTrace();
						}
					}

		}
			 else if (option.equals("3")) { // <<<<<-------------------OPTION3---------------------------->>>>>
					
					int row = 0;
					int col = 0;
					String[][] arrayValues = new String[100][100];
					int filenumber = 0;
					String csvFile = Filepath + "\\Filenames_Standalone.csv";
					// System.out.println("Please enter the Executable file");
					File f1 = new File(csvFile);
					if (f1.exists()) {

						BufferedReader bufRdr = new BufferedReader(new FileReader(csvFile));
						String line = "";
					
						// read each line of text file
						while ((line = bufRdr.readLine()) != null) {
							StringTokenizer st = new StringTokenizer(line, ",");
							while (st.hasMoreTokens()) {
								// get next token and store it in the array
								arrayValues[row][col] = st.nextToken();
								col++;
							}
							row++;
							col = 0;
						}
						bufRdr.close();
					}
						// close the file
						
					
					Scanner s1 = new Scanner(System.in);
					System.out.println("Please enter Test Date in YYYYMMDD Format");
					String date = s1.next();
					System.out.println("Please enter Test start hour in HH format");
					String time = s1.next();
					System.out.println("Please enter Test start minutes in MM format");
					int minutes = s1.nextInt();
					s1.close();
				//	System.out
					//.println("Please enter Spot Instance IP Address::");
			//String SFTPHOST = s1.next();
					//s1.close();
					int minutes1 = minutes / 10;
					int minutes2 = minutes1 + 1;
					// System.out.println("minutes"+minutes1+minutes2);
					/*
					 * for (int k = 0; k < row; k++) { String application =
					 * arrayValues[k][4]; //
					 * System.out.println("hostname"+hostname); if (application ==
					 * null) { break; } System.out.println("Please press " + k +
					 * " for " + application); }
					 * System.out.println("Please press all for All the Applications"
					 * ); Scanner s = new Scanner(System.in); String AppNum =
					 * s.next();
					 * 
					 * if (!AppNum.equals("all")) {
					 * 
					 * int AppNum1 = Integer.parseInt(AppNum); String SFTPWORKINGDIR
					 * = arrayValues[AppNum1][0]; String SFTPHOST =
					 * arrayValues[AppNum1][1]; String SFTPUSER =
					 * arrayValues[AppNum1][2]; String SFTPPASS =
					 * arrayValues[AppNum1][3]; String application =
					 * arrayValues[AppNum1][4];
					 */
			/*		for (int j = 0; j < row; j++) {
						String SFTPWORKINGDIR = arrayValues[j][0];
						String SFTPHOST = arrayValues[j][1];
						String SFTPUSER = arrayValues[j][2];
					String SFTPPASS = "No Password";
					String application = arrayValues[j][4];
						// System.out.println("hostname"+hostname);
				if (SFTPUSER == null) {
							break;
					}*/

						int SFTPPORT = 22;
						// String SFTPWORKINGDIR =
						// "/tui/jmeter/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT";

						Session session = null;
						Channel channel = null;
						ChannelSftp channelSftp = null;

						try {
							JSch jsch = new JSch();
							for (int j = 0; j < row; j++) {
								String SFTPWORKINGDIR = arrayValues[j][0];
								String SFTPHOST = arrayValues[j][1];
								String SFTPUSER = arrayValues[j][2];
							String SFTPPASS = "No Password";
							String application = arrayValues[j][4];
								// System.out.println("hostname"+hostname);
						if (SFTPUSER == null) {
									break;
							}
						//	for (int l = 0; l < row; l++) {
						//		String SFTPWORKINGDIR = arrayValues[l][0];
							//	String SFTPHOST = arrayValues[j][1];
							//	String SFTPUSER = "ec2-user";
						//		String SFTPPASS = "No Password";
						//		String application = arrayValues[l][4];
								// System.out.println("hostname"+hostname);
							//	if (SFTPUSER == null) {
						//			break;
						//		}
							session = jsch.getSession(SFTPUSER, SFTPHOST, SFTPPORT);
						//	session.setPassword(SFTPPASS);
							jsch.addIdentity(Filepath+"\\Services.ppk");
							java.util.Properties config = new java.util.Properties();
							config.put("StrictHostKeyChecking", "no");
							session.setConfig(config);
							session.connect();
							
							channel = session.openChannel("sftp");
							channel.connect();
							channelSftp = (ChannelSftp) channel;
							
						//	for (int l = 0; l < row; l++) {
					//			String SFTPWORKINGDIR = arrayValues[l][0];
							//	String SFTPHOST = arrayValues[j][1];
							//	 SFTPUSER = arrayValues[l][2];
							//	String SFTPPASS = "No Password";
						//		String application = arrayValues[l][4];
								// System.out.println("hostname"+hostname);
							//	if (application == null) {
							//		break;
							//	}
							channelSftp.cd(SFTPWORKINGDIR);
						//	channelSftp.
							Vector filelist = channelSftp.ls(SFTPWORKINGDIR);
							String[] listoffiles = new String[filelist.size()];
							for (int i = 0; i < filelist.size(); i++) {
								LsEntry entry = (LsEntry) filelist.get(i);
						//		 System.out.println(entry.getFilename());
								listoffiles[i] = entry.getFilename();

							}
							ArrayList<String> listoffiles2 = new ArrayList<String>();
							for (int j1 = 0; j1 < listoffiles.length; j1++) {

								if (listoffiles[j1].contains("data-load-test")) {
									listoffiles2.add(listoffiles[j1].replace(
											"data-load-test-", ""));
								}
							}

							if (listoffiles2.contains(date)) {

								List<Integer> newList = new ArrayList<Integer>(
										listoffiles2.size());
								for (String myInt : listoffiles2) {
									newList.add(Integer.valueOf(myInt));
								}
								// System.out.println(newList);
								Collections.sort(newList);
								Collections.reverse(newList);
								// System.out.println(newList);
								SFTPWORKINGDIR = SFTPWORKINGDIR + "/"
										+ "data-load-test-" + date;
								channelSftp.cd(SFTPWORKINGDIR);
								Vector filelist1 = channelSftp.ls(SFTPWORKINGDIR);
						//		Vector filelist32 = channelSftp.;
								String[] listinside = new String[filelist1.size()];
								for (int i = 0; i < filelist1.size(); i++) {
									LsEntry entry = (LsEntry) filelist1.get(i);
								//	 System.out.println(entry.getFilename());
									listinside[i] = entry.getFilename();
						//			channelSftp.exit();
						//			session.disconnect();
								}
								ArrayList<String> listoffiles3 = new ArrayList<String>();

								for (int j2 = 0; j2 < listinside.length; j2++) {
	//System.out.println("list of files::"+listinside[j2]);
									if (listinside[j2].contains(".jtl")
											&& (listinside[j2].contains("eport_"
													+ date + "-" + time + minutes1))
											|| listinside[j2].contains(".csv")
											&& (listinside[j2].contains("errors_"
													+ date + "-" + time + minutes1))) {
										System.out.println("list of files::"+listinside[j2]);
										listoffiles3.add(listinside[j2]);
									}

									if (listinside[j2].contains(".jtl")
											&& (listinside[j2].contains("eport_"
													+ date + "-" + time + minutes2))
											|| listinside[j2].contains(".csv")
											&& (listinside[j2].contains("errors_"
													+ date + "-" + time + minutes2))) {
										System.out.println("list of files::"+listinside[j2]);
										listoffiles3.add(listinside[j2]);
									}

								}

								if (minutes >= 50 && minutes <= 60) {
									for (int j2 = 0; j2 < listinside.length; j2++) {
										int temptime = Integer.parseInt(time);
										int temptime1 = temptime + 1;
										String temptime2 = Integer
												.toString(temptime1);
										if (temptime1 <= 9) {
											temptime2 = "0" + temptime2;
										}
										// System.out.println("temptime"+temptime2);
										if (listinside[j2].contains(".jtl")
												&& (listinside[j2]
														.contains("eport_" + date
																+ "-" + temptime2
																+ "0"))
												|| listinside[j2].contains(".csv")
												&& (listinside[j2]
														.contains("errors_" + date
																+ "-" + temptime2
																+ "0"))) {
											listoffiles3.add(listinside[j2]);
										}

									}
								}
								if (minutes > 60) {
									System.out.println("Please enter valid Time");
									break;
								}
								if (listoffiles3.size() != 0) {
									// System.out.println(listoffiles3+","+listoffiles3.size());
									System.out
											.println(application
													+ " Results Exists for the Given Dates and Copying File Names");
									BufferedWriter output = null;

									File file = new File(Filepath
											+ "\\FileNames\\Test" + filenumber
											+ ".csv");
									filenumber = filenumber + 1;
									output = new BufferedWriter(
											new FileWriter(file));
									// System.out.println("Application:"+application);

									for(int a=0;a<listoffiles3.size();a++){
										output.write(SFTPWORKINGDIR + "/"
												+ listoffiles3.get(a) + ","
												+ SFTPWORKINGDIR + "/"
												+ listoffiles3.get(a+1) + "," + SFTPHOST
												+ "," + SFTPUSER + "," + SFTPPASS + ","
												+ application);
										output.newLine();
										a++;
									}
								/*	output.write(SFTPWORKINGDIR + "/"
											+ listoffiles3.get(0) + ","
											+ SFTPWORKINGDIR + "/"
											+ listoffiles3.get(1) + "," + SFTPHOST
											+ "," + SFTPUSER + "," + SFTPPASS + ","
											+ application);
									if (listoffiles3.size() == 4) {
										output.newLine();
										output.write(SFTPWORKINGDIR + "/"
												+ listoffiles3.get(2) + ","
												+ SFTPWORKINGDIR + "/"
												+ listoffiles3.get(3) + ","
												+ SFTPHOST + "," + SFTPUSER + ","
												+ SFTPPASS + "," + application);
									}*/
									output.close();
								}

								else {
									System.out
											.println("**********For "
													+ application
													+ " application there is no results file for the TIME specified********");
								}
							} else {
								System.out
										.println("**********For "
												+ application
												+ " application there is no results file for the DATE specified********");
								
							}
							
							channelSftp.exit();
							session.disconnect();
						//	System.out.println("Session Disconnected...!!!");
						}
							
						
							
						 }

						catch (Exception ex) {
							ex.printStackTrace();
						}
					}
			 
			 
			 else if (option.equals("4")) { // <<<<<-------------------OPTION4---------------------------->>>>>

					String[][] arrayValues = new String[100][100];
					int filenumber = 0;
					String csvFile = Filepath + "\\FileNames.csv";
					// System.out.println("Please enter the Executable file");
					File f1 = new File(csvFile);
					if (f1.exists()) {

						BufferedReader bufRdr = new BufferedReader(new FileReader(csvFile));
						String line = "";
						int row = 0;
						int col = 0;
						// read each line of text file
						while ((line = bufRdr.readLine()) != null) {
							StringTokenizer st = new StringTokenizer(line, ",");
							while (st.hasMoreTokens()) {
								// get next token and store it in the array
								arrayValues[row][col] = st.nextToken();
								col++;
							}
							row++;
							col = 0;
						}
						// close the file
						bufRdr.close();
				 
				 
				Scanner s1 = new Scanner(System.in);
				System.out.println("Please enter Test Date in YYYYMMDD Format");
				String date = s1.next();
				System.out.println("Please enter Test start hour in HH format");
				String time = s1.next();
				System.out
						.println("Please enter Test start minutes in MM format");
				int minutes = s1.nextInt();
				System.out
				.println("Please enter Spot Instance IP Address::");
		String SFTPHOST = s1.next();
				//s1.close();
				int minutes1 = minutes / 10;
				int minutes2 = minutes1 + 1;
				// System.out.println("minutes"+minutes1+minutes2);
				/*
				 * for (int k = 0; k < row; k++) { String application =
				 * arrayValues[k][4]; //
				 * System.out.println("hostname"+hostname); if (application ==
				 * null) { break; } System.out.println("Please press " + k +
				 * " for " + application); }
				 * System.out.println("Please press all for All the Applications"
				 * ); Scanner s = new Scanner(System.in); String AppNum =
				 * s.next();
				 * 
				 * if (!AppNum.equals("all")) {
				 * 
				 * int AppNum1 = Integer.parseInt(AppNum); String SFTPWORKINGDIR
				 * = arrayValues[AppNum1][0]; String SFTPHOST =
				 * arrayValues[AppNum1][1]; String SFTPUSER =
				 * arrayValues[AppNum1][2]; String SFTPPASS =
				 * arrayValues[AppNum1][3]; String application =
				 * arrayValues[AppNum1][4];
				 */
			//	for (int j = 0; j < row; j++) {
			//		String SFTPWORKINGDIR = arrayValues[j][0];
				//	String SFTPHOST = arrayValues[j][1];
			//		String SFTPUSER = arrayValues[j][2];
			//		String SFTPPASS = "No Password";
			//		String application = arrayValues[j][4];
					// System.out.println("hostname"+hostname);
		//		if (SFTPUSER == null) {
			//			break;
		//			}

					int SFTPPORT = 22;
					// String SFTPWORKINGDIR =
					// "/tui/jmeter/Thomsonone/PT3_TRENCH_ATCOM/inst-a/results/TH_WebTestPlan_Results_PAT";

					Session session = null;
					Channel channel = null;
					ChannelSftp channelSftp = null;

					try {
						JSch jsch = new JSch();
					//	for (int l = 0; l < row; l++) {
					//		String SFTPWORKINGDIR = arrayValues[l][0];
						//	String SFTPHOST = arrayValues[j][1];
							String SFTPUSER = "ec2-user";
							String SFTPPASS = "No Password";
					//		String application = arrayValues[l][4];
							// System.out.println("hostname"+hostname);
						//	if (SFTPUSER == null) {
					//			break;
					//		}
						session = jsch.getSession(SFTPUSER, SFTPHOST, SFTPPORT);
					//	session.setPassword(SFTPPASS);
						jsch.addIdentity(Filepath+"\\Services.ppk");
						java.util.Properties config = new java.util.Properties();
						config.put("StrictHostKeyChecking", "no");
						session.setConfig(config);
						session.connect();
						
						channel = session.openChannel("sftp");
						channel.connect();
						channelSftp = (ChannelSftp) channel;
						
						for (int l = 0; l < row; l++) {
							String SFTPWORKINGDIR = arrayValues[l][0];
						//	String SFTPHOST = arrayValues[j][1];
						//	 SFTPUSER = arrayValues[l][2];
						//	String SFTPPASS = "No Password";
							String application = arrayValues[l][4];
							// System.out.println("hostname"+hostname);
							if (application == null) {
								break;
							}
						channelSftp.cd(SFTPWORKINGDIR);
					//	channelSftp.
						Vector filelist = channelSftp.ls(SFTPWORKINGDIR);
						String[] listoffiles = new String[filelist.size()];
						for (int i = 0; i < filelist.size(); i++) {
							LsEntry entry = (LsEntry) filelist.get(i);
							// System.out.println(entry.getFilename());
							listoffiles[i] = entry.getFilename();

						}
						ArrayList<String> listoffiles2 = new ArrayList<String>();
						for (int j1 = 0; j1 < listoffiles.length; j1++) {

							if (listoffiles[j1].contains("data-load-test")) {
								listoffiles2.add(listoffiles[j1].replace(
										"data-load-test-", ""));
							}
						}

						if (listoffiles2.contains(date)) {

							List<Integer> newList = new ArrayList<Integer>(
									listoffiles2.size());
							for (String myInt : listoffiles2) {
								newList.add(Integer.valueOf(myInt));
							}
							// System.out.println(newList);
							Collections.sort(newList);
							Collections.reverse(newList);
							// System.out.println(newList);
							SFTPWORKINGDIR = SFTPWORKINGDIR + "/"
									+ "data-load-test-" + date;
							channelSftp.cd(SFTPWORKINGDIR);
							Vector filelist1 = channelSftp.ls(SFTPWORKINGDIR);
							String[] listinside = new String[filelist1.size()];
							for (int i = 0; i < filelist1.size(); i++) {
								LsEntry entry = (LsEntry) filelist1.get(i);

								listinside[i] = entry.getFilename();
					//			channelSftp.exit();
					//			session.disconnect();
							}
							ArrayList<String> listoffiles3 = new ArrayList<String>();

							for (int j2 = 0; j2 < listinside.length; j2++) {
//System.out.println("list of files::"+listinside[j2]);
								if (listinside[j2].contains(".jtl")
										&& (listinside[j2].contains("eport_"
												+ date + "-" + time + minutes1))
										|| listinside[j2].contains(".csv")
										&& (listinside[j2].contains("errors_"
												+ date + "-" + time + minutes1))) {
									System.out.println("list of files::"+listinside[j2]);
									listoffiles3.add(listinside[j2]);
								}

								if (listinside[j2].contains(".jtl")
										&& (listinside[j2].contains("eport_"
												+ date + "-" + time + minutes2))
										|| listinside[j2].contains(".csv")
										&& (listinside[j2].contains("errors_"
												+ date + "-" + time + minutes2))) {
									System.out.println("list of files::"+listinside[j2]);
									listoffiles3.add(listinside[j2]);
								}

							}

							if (minutes >= 50 && minutes <= 60) {
								for (int j2 = 0; j2 < listinside.length; j2++) {
									int temptime = Integer.parseInt(time);
									int temptime1 = temptime + 1;
									String temptime2 = Integer
											.toString(temptime1);
									if (temptime1 <= 9) {
										temptime2 = "0" + temptime2;
									}
									// System.out.println("temptime"+temptime2);
									if (listinside[j2].contains(".jtl")
											&& (listinside[j2]
													.contains("eport_" + date
															+ "-" + temptime2
															+ "0"))
											|| listinside[j2].contains(".csv")
											&& (listinside[j2]
													.contains("errors_" + date
															+ "-" + temptime2
															+ "0"))) {
										listoffiles3.add(listinside[j2]);
									}

								}
							}
							if (minutes > 60) {
								System.out.println("Please enter valid Time");
								break;
							}
							if (listoffiles3.size() != 0) {
								// System.out.println(listoffiles3+","+listoffiles3.size());
								System.out
										.println(application
												+ " Results Exists for the Given Dates and Copying File Names");
								BufferedWriter output = null;

								File file = new File(Filepath
										+ "\\FileNames\\Test" + filenumber
										+ ".csv");
								filenumber = filenumber + 1;
								output = new BufferedWriter(
										new FileWriter(file));
								// System.out.println("Application:"+application);

								for(int a=0;a<listoffiles3.size();a++){
									output.write(SFTPWORKINGDIR + "/"
											+ listoffiles3.get(a) + ","
											+ SFTPWORKINGDIR + "/"
											+ listoffiles3.get(a+1) + "," + SFTPHOST
											+ "," + SFTPUSER + "," + SFTPPASS + ","
											+ application);
									output.newLine();
									a++;
								}
							/*	output.write(SFTPWORKINGDIR + "/"
										+ listoffiles3.get(0) + ","
										+ SFTPWORKINGDIR + "/"
										+ listoffiles3.get(1) + "," + SFTPHOST
										+ "," + SFTPUSER + "," + SFTPPASS + ","
										+ application);
								if (listoffiles3.size() == 4) {
									output.newLine();
									output.write(SFTPWORKINGDIR + "/"
											+ listoffiles3.get(2) + ","
											+ SFTPWORKINGDIR + "/"
											+ listoffiles3.get(3) + ","
											+ SFTPHOST + "," + SFTPUSER + ","
											+ SFTPPASS + "," + application);
								}*/
								output.close();
							}

							else {
								System.out
										.println("**********For "
												+ application
												+ " application there is no results file for the TIME specified********");
							}
						} else {
							System.out
									.println("**********For "
											+ application
											+ " application there is no results file for the DATE specified********");
							
						}
						
					}
						channelSftp.exit();
						session.disconnect();
						System.out.println("Session Disconnected...!!!");
					}
					
					// }

					catch (Exception ex) {
						ex.printStackTrace();
					}
					
			//	}

			}
			else {
				System.out.println("Please enter a valid option..");
			}

		}		 
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 else {
			System.out
					.println("Make sure Filenames.csv Exists in the path specified..");
		}
	}
}
